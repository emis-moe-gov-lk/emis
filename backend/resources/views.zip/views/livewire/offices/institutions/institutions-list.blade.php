<div>
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Institution') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">
            {{ __('Manage institution profile and account') }}
        </flux:subheading>
        <flux:separator variant="subtle" />

        <div class="flex items-center space-x-3 my-4">
            <span class="text-sm text-gray-500 dark:text-gray-400">
                Total: {{ $institutions->total() }} Institution
            </span>
        </div>
        <div class="overflow-x-auto shadow-md">
            <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700">
                <thead class="bg-slate-50 dark:bg-slate-800">
                    <tr>
                        <th
                            class="px-4 py-3 text-left text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                            #
                        </th>
                        <th
                            class="px-4 py-3 text-left text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                            Name
                        </th>
                        <th
                            class="px-4 py-3 text-left text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                            Address
                        </th>
                        <th
                            class="px-4 py-3 text-left text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                            Zone
                        </th>
                        <th
                            class="px-4 py-3 text-left text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                            Status
                        </th>
                        <th
                            class="px-4 py-3 text-right text-xs font-semibold text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                            Actions
                        </th>
                    </tr>
                </thead>
                <tbody class="bg-white dark:bg-slate-900 divide-y divide-slate-200 dark:divide-slate-700">
                    @forelse ($institutions as $key => $institution)
                        <tr class="hover:bg-slate-100 dark:hover:bg-slate-800 transition duration-150">
                            <!-- Index -->
                            <td class="px-4 py-3 whitespace-nowrap text-sm text-slate-900 dark:text-slate-100">
                                {{ $institutions->firstItem() + $key }}
                            </td>

                            <!-- Name & Logo -->
                            <td class="px-4 py-3 whitespace-nowrap">
                                <div class="flex items-center space-x-3">
                                    <div class="flex-shrink-0 h-10 w-10">
                                        <svg class="h-8 w-8 text-gray-400 dark:text-gray-500"
                                            xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 16 16">
                                            <path
                                                d="M8.277.084a.5.5 0 0 0-.554 0l-7.5 5A.5.5 0 0 0 .5 6h1.875v7H1.5a.5.5 0 0 0 0 1h13a.5.5 0 1 0 0-1h-.875V6H15.5a.5.5 0 0 0 .277-.916zM12.375 6v7h-1.25V6zm-2.5 0v7h-1.25V6zm-2.5 0v7h-1.25V6zm-2.5 0v7h-1.25V6zM8 4a1 1 0 1 1 0-2 1 1 0 0 1 0 2M.5 15a.5.5 0 0 0 0 1h15a.5.5 0 1 0 0-1z" />
                                        </svg>
                                    </div>
                                    <div>
                                        <div class="text-sm font-medium text-slate-900 dark:text-slate-100">
                                            @can('office.institution.profile.overview.view')
                                                <flux:link
                                                    href="{{ route('institutions.profile.overview', $institution->id) }}"
                                                    variant="ghost">
                                                    {{ $institution->name }}
                                                </flux:link>
                                            @else
                                                {{ $institution->name }}
                                            @endcan
                                        </div>
                                        <div class="text-xs text-slate-500 dark:text-slate-400">
                                            Census No: {{ str_pad($institution->census_no, 5, '0', STR_PAD_LEFT) }}
                                        </div>
                                    </div>
                                </div>
                            </td>

                            <!-- Address -->
                            <td class="px-4 py-3 whitespace-nowrap text-sm text-slate-900 dark:text-slate-100">
                                {{ $institution->address }}
                                <div class="text-xs text-slate-500 dark:text-slate-400">
                                    Contact: {{ $institution->phone ?? 'N/A' }}
                                </div>
                            </td>

                            <!-- Zone -->
                            <td class="px-4 py-3 whitespace-nowrap text-sm text-slate-900 dark:text-slate-100">
                                ZEO: {{ $institution->zonalEducationOffice->short_name ?? 'N/A' }}<br>
                                DEO: {{ $institution->divisionalEducationOffice->short_name ?? 'N/A' }}
                            </td>

                            <!-- Status -->
                            <td class="px-4 py-3 whitespace-nowrap">
                                <span
                                    class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                            {{ $institution->active_status ? 'bg-green-100 text-green-800 dark:bg-green-700 dark:text-green-100' : 'bg-red-100 text-red-800 dark:bg-red-700 dark:text-red-100' }}">
                                    {{ $institution->active_status ? 'Active' : 'Inactive' }}
                                </span>
                            </td>

                            <!-- Actions -->
                            <td
                                class="px-4 py-3 whitespace-nowrap text-right text-sm font-medium flex justify-end gap-2">
                                @can('office.institution.profile.overview.view')
                                    <a href="{{ route('institutions.profile.overview', $institution->id) }}">
                                        <flux:button size="sm" icon="eye">View</flux:button>
                                    </a>
                                @endcan

                                @can('office.institution.update')
                                    <a href="#">
                                        <flux:button size="sm" icon="pencil-square">Edit</flux:button>
                                    </a>
                                @endcan
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="text-center py-6 text-slate-500 dark:text-slate-400">
                                No institutions found.
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>


        <div class="mt-4 mx-10">
            {{ $institutions->links() }}
        </div>
    </div>
</div>
