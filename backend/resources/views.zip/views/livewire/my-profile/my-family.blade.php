<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('My Profile') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage My profile and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-my-profile.my-profile-layout>
        <livewire:employees.family-information :peopleId="$people->people_id" :canCreate="auth()->user()->can('my-profile.family.create')" :canDelete="auth()->user()->can('my-profile.family.delete')" />
    </x-my-profile.my-profile-layout>
</section>