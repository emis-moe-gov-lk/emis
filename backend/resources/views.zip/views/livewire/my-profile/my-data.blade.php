<div>
    @if (auth()->user()->currentAppointment->service_id)
    @switch(auth()->user()->currentAppointment->service_id)
    @case('SER001')
    <livewire:teacher.profile.teacher-data :peopleId="$people_id" />
    @break
    @case('SER002')
    <livewire:sltes.profile.sltes-data :peopleId="$people_id" />
    @break
    @case('SER003')
    <livewire:sltas.profile.sltas-data :peopleId="$people_id" />
    @break
    @case('SER004')
    <livewire:principal.profile.principal-data :peopleId="$people_id" />
    @break
    @case('SER005')
    <livewire:sleas.profile.sleas-data :peopleId="$people_id" />
    @break
    @case('SER006')
    <div></div>
    @break
    @case('SER007')
    <livewire:d-o-s.profile.d-o-s-data :peopleId="$people_id" />
    @break
    @case('SER008')
    <livewire:m-s-o.profile.m-s-o-data :peopleId="$people_id" />
    @break
    @default
    <p>Unknown</p>
    @endswitch
    @endif
</div>