<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('My Profile') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage My profile and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-my-profile.my-profile-layout>
        <div>
            <div class="antialiased min-h-screen">

                {{-- Main Dual-Mode Card (Read-Only Container) --}}
                <div class="bg-white dark:bg-gray-800 p-4 rounded-b-lg">

                    {{-- Main Content Grid --}}
                    <div class="space-y-6">

                        {{-- 1. Personal & Socio-Cultural Details --}}
                        <livewire:employees.personal-cultural :peopleId="$peopleId" :canEdit="auth()->user()->can('my-profile.personal-cultural.update')" />

                        {{-- 2. Health information --}}
                        <livewire:employees.health-information :peopleId="$peopleId" :canEdit="auth()->user()->can('my-profile.health.update')" />

                        {{-- 3. Contact Information --}}
                        <livewire:employees.contact-information :peopleId="$peopleId" :canEdit="auth()->user()->can('my-profile.contact-information.update')" />

                        {{-- 4. Location Information --}}
                        <livewire:employees.location-information :peopleId="$peopleId" :canEdit="auth()->user()->can('my-profile.location-information.update')" />

                        {{-- 4. Temporary Location Information --}}
                        <livewire:employees.temporary-location-information :peopleId="$peopleId" :canEdit="auth()->user()->can('my-profile.temporary-location-information.update')" />

                        {{-- 5. Audit Data (NIC Hash) --}}
                        <section class="pt-4 border-t border-gray-200 dark:border-gray-700">
                            <p class="text-xs font-mono text-gray-500 dark:text-gray-600">
                                **NIC Hash (System Key):** {{ $myprofile->nic_hash }}
                            </p>
                        </section>

                    </div>

                </div>
            </div>
        </div>

    </x-my-profile.my-profile-layout>
</section>