
<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Teacher Advisor Profile') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Teacher Advisor profile and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-sltas.sltas-profile-layout :sltasid="$id">
        <livewire:employees.family-information :peopleId="$sltas->people_id" :canCreate="auth()->user()->can('sltas.profile.family.create')" :canDelete="auth()->user()->can('sltas.profile.family.delete')"/>
    </x-sltas.sltas-profile-layout>
</section>