<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Teacher Advisor Profile') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Teacher Advisor profile and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-sltas.sltas-profile-layout :sltasid="$id">
        <div>
            <div class="antialiased min-h-screen">

                {{-- Main Dual-Mode Card (Read-Only Container) --}}
                <div class="bg-white dark:bg-gray-800 p-4 rounded-b-lg">

                    {{-- Main Content Grid --}}
                    <div class="space-y-6">

                        {{-- 1. Personal & Socio-Cultural Details --}}
                        <livewire:employees.educational-qualification :peopleId="$sltas->people_id" :canCreate="auth()->user()->can('sltas.profile.qualification.create')" :canDelete="auth()->user()->can('sltas.profile.qualification.delete')"/>

                        {{-- 4. Audit Data (NIC Hash) --}}
                        <section class="pt-4 border-t border-gray-200 dark:border-gray-700">
                            <p class="text-xs font-mono text-gray-500 dark:text-gray-600">
                                **NIC Hash (System Key):** {{ $sltas->nic_hash }}
                            </p>
                        </section>
                    </div>

                </div>
            </div>
        </div>
    </x-sltas.sltas-profile-layout>
</section>
