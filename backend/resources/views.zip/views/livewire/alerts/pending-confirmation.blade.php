<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Alerts Overview') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Alerts!') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-alerts.layout>

        <div class="relative mb-6 w-full">
            <flux:heading size="xl" level="1">{{ __('Pending Confirmation List for') }} {{ Auth::user()->workplace?->office_name ?? 'All Workplaces' }}</flux:heading>
            <flux:subheading size="lg" class="mb-6">{{ __('Manage pending confirmation profile and account') }}
            </flux:subheading>
            <flux:separator variant="subtle" />

            <div>
                @if (session('success'))
                <x-alert type="success" dismissible class="mb-4">
                    {{ session('success') }}
                </x-alert>
                @endif

                @if (session('error'))
                <x-alert type="error" dismissible class="mb-4">
                    {{ session('error') }}
                </x-alert>
                @endif

                @if (session('warning'))
                <x-alert type="warning" dismissible class="mb-4">
                    {{ session('warning') }}
                </x-alert>
                @endif

                @if (session('info'))
                <x-alert type="info" dismissible class="mb-4">
                    {{ session('info') }}
                </x-alert>
                @endif
            </div>

            <div class="my-6 flex items-center justify-end gap-3">

                {{-- Search Button (Modal Trigger) --}}
                <flux:modal.trigger name="search-profile">
                    <flux:input as="button" placeholder="Search Profile..." icon="magnifying-glass" kbd="⌘K"
                        class="w-48 md:w-60 cursor-pointer transition-all hover:shadow-sm focus:ring-2 focus:ring-blue-500" />
                </flux:modal.trigger>

                {{-- Search Modal --}}
                <flux:modal name="search-profile" class="md:w-[28rem] rounded-xl shadow-lg">
                    <div class="space-y-6 p-4">
                        {{-- Header --}}
                        <div class="text-center">
                            <flux:heading size="lg" class="text-gray-800 dark:text-gray-100">
                                Search Pending Confirmation Profile
                            </flux:heading>
                            <flux:text class="mt-2 text-gray-500 dark:text-gray-400 text-sm">
                                Search for a pending confirmation profile by
                                <span class="font-semibold text-gray-700 dark:text-gray-300">NIC or email or contact number </span>.
                            </flux:text>
                        </div>

                        {{-- Search Input --}}
                        <div>
                            <flux:input icon="magnifying-glass" wire:model.live="query" placeholder="Type NIC or email or contact number..."
                                class="w-full focus:ring-2 focus:ring-blue-500" />
                        </div>

                        {{-- Results --}}
                        @if (!empty($results) && count($results) > 0)
                        <ul class="divide-y divide-gray-200 dark:divide-gray-700 mt-2">
                            @foreach ($results as $employee)
                            <li
                                class="py-2 px-3 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md cursor-pointer transition">
                                @php
                                    // Determine route based on service
                                    $routeName = match($employee->currentAppointment->service_id) {
                                        'SER001' => 'teacher.profile.index',
                                        'SER002' => 'sltes.profile.index',
                                        'SER003' => 'sltas.profile.index',
                                        'SER004' => 'principal.profile.index',
                                        'SER005' => 'sleas.profile.index',
                                        'SER006' => 'slas.profile.index',
                                        'SER007' => 'dos.profile.index',
                                        'SER008' => 'mso.profile.index',
                                    };
                                @endphp

                                <a href="{{ route($routeName, $employee->id) }}">
                                    <div class="flex justify-between items-center">
                                        <span class="font-semibold text-gray-800 dark:text-gray-100">
                                            {{ $employee->name_with_initials }}
                                        </span>
                                        <span class="text-sm text-gray-500 dark:text-gray-400">
                                            {{ $employee->nic }}
                                        </span>
                                    </div>
                                </a>

                            </li>
                            @endforeach
                        </ul>
                        @elseif(strlen($query) >= 10)
                        <p class="text-sm text-gray-500 dark:text-gray-400 text-center py-2">
                            No pending confirmation profile found.
                        </p>
                        @endif


                    </div>
                </flux:modal>


            </div>

            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200 border rounded-lg overflow-hidden shadow-sm">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wide">
                                Name
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wide">
                                Designation
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wide">
                                Status
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wide">
                                Last update
                            </th>
                            <th class="px-6 py-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wide">
                                Actions
                            </th>
                        </tr>
                    </thead>

                    <tbody class="bg-white divide-y divide-gray-200">
                        @forelse($employees as $employee)
                        <tr class="hover:bg-gray-50 transition-colors duration-150">
                            <!-- Name Section -->
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center gap-4">
                                    <div class="h-11 w-11 rounded-full overflow-hidden border">
                                        <img class="h-full w-full object-cover"
                                            src="{{ $employee->gender_id == 'G02' ? asset('images/profile_f.png') : asset('images/profile_m.png') }}"
                                            alt="Profile">
                                    </div>

                                    <div>
                                        <div class="text-sm font-semibold text-gray-900 flex items-center gap-1">
                                            <flux:link href="{{ route('sltas.profile.index', $employee->id) }}" variant="ghost">
                                                {{ $employee->title->title_name ?? '' }} {{ $employee->name_with_initials }}
                                            </flux:link>
                                        </div>
                                        <div class="text-xs text-gray-500">
                                            NIC: <span class="font-medium">{{ $employee->nic }}</span>
                                        </div>
                                    </div>
                                </div>
                            </td>

                            <!-- Designation Section -->
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-gray-900">
                                    {{ $employee->currentAppointment?->position?->position_name ?? 'N/A' }}
                                </div>
                                <div class="text-xs text-gray-500">
                                    {{ $employee->currentAppointment?->service?->service_name ?? 'N/A' }}
                                </div>
                            </td>

                            <!-- Status -->
                            <td class="px-6 py-4 whitespace-nowrap">
                                @if($employee->currentAppointment?->appointment?->is_confirmed)
                                <span
                                    class="px-2 py-0.5 rounded-full bg-green-100 text-green-700 text-xs font-semibold inline-flex items-center">
                                    Confirmed
                                </span>
                                @else
                                <span
                                    class="px-2 py-0.5 rounded-full bg-yellow-100 text-yellow-700 text-xs font-semibold inline-flex items-center">
                                    Not Confirmed
                                </span>
                                @endif
                            </td>

                            <!-- Last Update -->
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-gray-900">
                                    {{ $employee->updated_at->format('Y-m-d') }}
                                </div>
                            </td>

                            <!-- Actions -->
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <div class="flex justify-end gap-2">

                                    @php
                                        // Determine route name based on service
                                        $routeName = match($employee->currentAppointment->service_id) {
                                            'SER001' => 'teacher.profile.index',
                                            'SER002' => 'sltes.profile.index',
                                            'SER003' => 'sltas.profile.index',
                                            'SER004' => 'principal.profile.index',
                                            'SER005' => 'sleas.profile.index',
                                            'SER006' => 'slas.profile.index',
                                            'SER007' => 'dos.profile.index',
                                            'SER008' => 'mso.profile.index',
                                        };
                                    @endphp

                                    <a href="{{ route($routeName, $employee->id) }}">
                                        <flux:button size="sm" icon="eye" variant="ghost">View</flux:button>
                                    </a>

                                </div>
                            </td>
                        </tr>

                        @empty
                        <tr>
                            <td colspan="9" class="text-center py-8">
                                <span class="text-gray-400 text-sm">No employees found</span>
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div class="mt-4">
                {{ $employees->links() }}
            </div>

        </div>
        
    </x-alerts.layout>
</section>
