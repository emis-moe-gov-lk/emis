<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Alerts Overview') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Alerts!') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-alerts.layout>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
    
            @canany([
                'teacher.profile.confirm',
                'principal.profile.confirm',
                'dos.profile.confirm',
                'mso.profile.confirm',
                'sleas.profile.confirm',
                'sltas.profile.confirm',
                'sltes.profile.confirm'
            ])
                @if ($pendingConfirmationCount > 0)
                    <div class="aspect-square flex flex-col items-center justify-center rounded-xl bg-green-50 border border-green-200 shadow-sm transition hover:shadow-md">
                        <div class="mt-3 p-2 bg-green-200 rounded-full mb-10">
                            <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                        </div>
                        <span class="text-4xl font-bold text-green-600">{{ $pendingConfirmationCount }}</span>
                        <span class="text-sm font-semibold text-green-700 mt-2 mb-2">Pending Confirmation</span>
                        <a href="{{ route('alerts.pending-confirmation') }}">
                            <flux:button variant="primary" size="sm" class="mt-2 bg-green-500 hover:bg-green-600 text-white" icon="eye">
                                View
                            </flux:button>
                        </a>
                    </div>
                @endif
            @endcanany

            @canany([
                'teacher.profile.verify',
                'principal.profile.verify',
                'dos.profile.verify',
                'mso.profile.verify',
                'sleas.profile.verify',
                'sltas.profile.verify',
                'sltes.profile.verify'
            ])
                @if ($pendingVerificationCount > 0)
                    <div class="aspect-square flex flex-col items-center justify-center rounded-xl bg-yellow-50 border border-yellow-200 shadow-sm transition hover:shadow-md">
                        <div class="mt-3 p-2 bg-yellow-200 rounded-full mb-10">
                            <svg class="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
                        </div>
                        <span class="text-4xl font-bold text-yellow-600">{{ $pendingVerificationCount }}</span>
                        <span class="text-sm font-semibold text-yellow-700 mt-2 mb-2">Pending Verification</span>
                        <a href="{{ route('alerts.pending-verification') }}">
                            <flux:button variant="primary" size="sm" class="mt-2 bg-yellow-500 hover:bg-yellow-600 text-white" icon="eye">View</flux:button>
                        </a>
                    </div>
                @endif
            @endcanany

        </div>

    </x-alerts.layout>
</section>
