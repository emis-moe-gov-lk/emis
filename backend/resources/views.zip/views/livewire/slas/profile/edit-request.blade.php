<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Sri Lanka Administrator Service Officer Profile') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Sri Lanka Administrator Service Officer profile and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-slas.slas-profile-layout :slasid="$id">
        <div>
            <div class="antialiased min-h-screen">

                {{-- Main Dual-Mode Card (Read-Only Container) --}}
                <div class="bg-white dark:bg-gray-800 p-4 rounded-b-lg">

                    {{-- Main Content Grid --}}
                    <div class="space-y-6">

                        {{-- 1. Personal & Socio-Cultural Details --}}
                        <livewire:employees.edit-request :peopleId="$people->people_id" />

                        {{-- 4. Audit Data (NIC Hash) --}}
                        <section class="pt-4 border-t border-gray-200 dark:border-gray-700">
                            <p class="text-xs font-mono text-gray-500 dark:text-gray-600">
                                **NIC Hash (System Key):** {{ $people->nic_hash }}
                            </p>
                        </section>

                    </div>

                </div>
            </div>
        </div>

    </x-slas.slas-profile-layout>
</section>