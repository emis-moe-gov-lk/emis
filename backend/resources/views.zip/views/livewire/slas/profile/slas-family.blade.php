
<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Sri Lanka Administrator Service Officer Profile') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Sri Lanka Administrator Service Officer profile and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-slas.slas-profile-layout :slasid="$id">
        <livewire:employees.family-information :peopleId="$slas->people_id" :canCreate="auth()->user()->can('slas.profile.family.create')" :canDelete="auth()->user()->can('slas.profile.family.delete')"/>
    </x-slas.slas-profile-layout>
</section>