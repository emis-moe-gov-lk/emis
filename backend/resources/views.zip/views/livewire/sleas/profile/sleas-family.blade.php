
<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Education Administrator Officer Profile') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Education Administrator Officer profile and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-sleas.sleas-profile-layout :sleasid="$id">
        <livewire:employees.family-information :peopleId="$sleas->people_id" :canCreate="auth()->user()->can('sleas.profile.family.create')" :canDelete="auth()->user()->can('sleas.profile.family.delete')"/>
    </x-sleas.sleas-profile-layout>
</section>