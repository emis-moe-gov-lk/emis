<div>
    <section>
        <div class="mb-3">
            <div class="flex items-baseline justify-between py-2">
                <div class="items-center justify-center flex gap-2">
                    <flux:badge variant="pill" icon="academic-cap">
                        {{ $employee->appointment->service->service_name ?? 'N/A' }}
                    </flux:badge>
                    <span class="text-lg font-bold text-gray-800 dark:text-gray-200 ">SLEAS Info</span>
                </div>
                @can('sleas.profile.employment.sleas-information.update')
                <flux:modal.trigger name="sleas-data-edit">
                    <flux:button icon="pencil-square" size="sm">Edit</flux:button>
                </flux:modal.trigger>
                @endcan
            </div>
            <flux:separator variant="subtle" />
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4 mb-4">

            {{-- Service --}}
            <div class="p-2 bg-white dark:bg-gray-700 rounded-md shadow-sm border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">SLEAS recruitment category
                </p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $sleasData->recruitmentCategory?->category_name ?? 'N/A' }}
                </p>
            </div>

            {{-- Subject --}}
            <div class="p-2 bg-white dark:bg-gray-700 rounded-md shadow-sm border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">SLEAS recruitment subject
                </p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $sleasData->serviceSubject?->subject ?? 'N/A' }}
                </p>
            </div>

        </div>

    </section>

    {{-- Update Employment --}}
    @can('sleas.profile.employment.sleas-information.update')
    <flux:modal name="sleas-data-edit" class="md:w-150">
        <div class="space-y-6">
            <div>
                <flux:heading size="lg">SLEAS Data</flux:heading>
                <flux:text class="mt-2">Make changes to your SLEAS details.</flux:text>
            </div>
            <form wire:submit.prevent="save">
                @csrf
                <div class="space-y-6">
                    <flux:field>
                        <flux:select label="SLEAS recruitment category" wire:model.live.debounce.150ms="sleasCategory">
                            <option value="">Select</option>
                            @foreach ($sleasCategoriesOption as $data)
                            <option value="{{ $data->category_id }}">{{ $data->category_name }}</option>
                            @endforeach
                        </flux:select>
                    </flux:field>

                    <flux:field>
                        <flux:select label="SLEAS recruitment subject" wire:model.live.debounce.150ms="sleasSubject">
                            <option value="">Select</option>
                            @foreach ($sleasSubjectsOption as $data)
                            <option value="{{ $data->eas_subject_id }}">{{ $data->subject }}</option>
                            @endforeach
                        </flux:select>
                    </flux:field>
                </div>

                <div class="flex mt-4">
                    <flux:spacer />

                    <div class="gap-2">
                        <flux:button type="button" wire:click="resetFields">Reset</flux:button>
                        <flux:button type="submit" variant="primary">Save changes</flux:button>
                    </div>
                </div>

            </form>

        </div>
    </flux:modal>
    @endcan
</div>