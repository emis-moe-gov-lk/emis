<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Sri Lanka Accountant Service Officer Profile') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Sri Lanka Accountant Service Officer profile and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-slacs.slacs-profile-layout :slacsid="$id">
        <div>
            <div class="antialiased min-h-screen">

                {{-- Main Dual-Mode Card (Read-Only Container) --}}
                <div class="bg-white dark:bg-gray-800 p-4 rounded-b-lg">

                    {{-- Main Content Grid --}}
                    <div class="space-y-6">

                        {{-- 1. Personal & Socio-Cultural Details --}}
                        <livewire:employees.educational-qualification :peopleId="$slacs->people_id" :canCreate="auth()->user()->can('slacs.profile.qualification.create')" :canDelete="auth()->user()->can('slacs.profile.qualification.delete')"/>

                        {{-- 4. Audit Data (NIC Hash) --}}
                        <section class="pt-4 border-t border-gray-200 dark:border-gray-700">
                            <p class="text-xs font-mono text-gray-500 dark:text-gray-600">
                                **NIC Hash (System Key):** {{ $slacs->nic_hash }}
                            </p>
                        </section>
                    </div>

                </div>
            </div>
        </div>
    </x-slacs.slacs-profile-layout>
</section>
