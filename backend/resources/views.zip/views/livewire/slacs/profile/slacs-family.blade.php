
<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Sri Lanka Accountant Service Officer Profile') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Sri Lanka Accountant Service Officer profile and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-slacs.slacs-profile-layout :slacsid="$id">
        <livewire:employees.family-information :peopleId="$slacs->people_id" :canCreate="auth()->user()->can('slacs.profile.family.create')" :canDelete="auth()->user()->can('slacs.profile.family.delete')"/>
    </x-slacs.slacs-profile-layout>
</section>