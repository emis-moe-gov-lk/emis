<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Sri Lanka Accountant Service Officer Profile') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Sri Lanka Accountant Service Officer profile and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-slacs.slacs-profile-layout :slacsid="$id">
        <div>
            <div class="antialiased min-h-screen">

                {{-- Main Dual-Mode Card (Read-Only Container) --}}
                <div class="bg-white dark:bg-gray-800 p-4 rounded-b-lg">

                    {{-- Main Content Grid --}}
                    <div class="space-y-6">

                        {{-- 1. Personal & Socio-Cultural Details --}}
                        <livewire:employees.personal-cultural :peopleId="$slacs->people_id" :canEdit="auth()->user()->can('slacs.profile.personal-cultural.update')"/>

                        {{-- 2. Health information --}}
                        <livewire:employees.health-information :peopleId="$slacs->people_id" :canEdit="auth()->user()->can('slacs.profile.health.update')"/>

                        {{-- 3. Contact Information --}}
                        <livewire:employees.contact-information :peopleId="$slacs->people_id" :canEdit="auth()->user()->can('slacs.profile.contact-information.update')"/>

                        {{-- 4. Location Information --}}
                        <livewire:employees.location-information :peopleId="$slacs->people_id" :canEdit="auth()->user()->can('slacs.profile.location-information.update')"/>

                        {{-- 4. Temporary Location Information --}}
                        <livewire:employees.temporary-location-information :peopleId="$slacs->people_id" :canEdit="auth()->user()->can('slacs.profile.temporary-location-information.update')" />

                        {{-- 5. Audit Data (NIC Hash) --}}
                        <section class="pt-4 border-t border-gray-200 dark:border-gray-700">
                            <p class="text-xs font-mono text-gray-500 dark:text-gray-600">
                                **NIC Hash (System Key):** {{ $slacs->nic_hash }}
                            </p>
                        </section>

                    </div>

                </div>
            </div>
        </div>

    </x-slacs.slacs-profile-layout>
</section>
