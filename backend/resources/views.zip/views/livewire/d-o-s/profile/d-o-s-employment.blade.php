<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Development Officer Profile') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Development Officer profile and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-d-o-s.d-o-s-profile-layout :dosid="$id">
        <div>
            <div class="antialiased min-h-screen">

                {{-- Main Dual-Mode Card (Read-Only Container) --}}
                <div class="bg-white dark:bg-gray-800 p-4 rounded-b-lg">

                    {{-- Main Content Grid --}}
                    <div class="space-y-6">

                        {{-- 1. Current Employment --}}
                        <livewire:employees.appointment-current-status :peopleId="$people->people_id" :canEdit="auth()->user()->can('dos.profile.employment.current-appointment.update')"/>

                        {{-- 2. First Employment --}}
                        <livewire:employees.first-appointment :peopleId="$people->people_id" :canEdit="auth()->user()->can('dos.profile.employment.first-appointment.update')"/>
                        <livewire:d-o-s.profile.d-o-s-data :peopleId="$people->people_id" />

                        {{-- 3. Previous Services --}}
                        <livewire:employees.previous-services-reg :peopleId="$people->people_id" :canCreate="auth()->user()->can('dos.profile.employment.previous-service.create')" :canDelete="auth()->user()->can('dos.profile.employment.previous-service.delete')"/>
                            
                        {{-- 4. Employment Service History --}}
                        <livewire:employees.services-history :peopleId="$people->people_id" :canCreate="auth()->user()->can('dos.profile.employment.services-history.create')" :canDelete="auth()->user()->can('dos.profile.employment.services-history.delete')" />
                        

                        {{-- 5. Audit Data (NIC Hash) --}}
                        <section class="pt-4 border-t border-gray-200 dark:border-gray-700">
                            <p class="text-xs font-mono text-gray-500 dark:text-gray-600">
                                **NIC Hash (System Key):** {{ $people->nic_hash }}
                            </p>
                        </section>

                    </div>

                </div>
            </div>
        </div>

    </x-d-o-s.d-o-s-profile-layout>
</section>
