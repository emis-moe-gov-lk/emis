
<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Development Officer Profile') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Development Officer profile and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-d-o-s.d-o-s-profile-layout :dosid="$id">
        <livewire:employees.family-information :peopleId="$dos->people_id" :canCreate="auth()->user()->can('dos.profile.family.create')" :canDelete="auth()->user()->can('dos.profile.family.delete')"/>
    </x-d-o-s.d-o-s-profile-layout>
</section>