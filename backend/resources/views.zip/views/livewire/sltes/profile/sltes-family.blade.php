
<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Teacher Educator Profile') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Teacher Educator profile and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-sltes.sltes-profile-layout :sltesid="$id">
        <livewire:employees.family-information :peopleId="$sltes->people_id" :canCreate="auth()->user()->can('sltes.profile.family.create')" :canDelete="auth()->user()->can('sltes.profile.family.delete')"/>
    </x-sltes.sltes-profile-layout>
</section>