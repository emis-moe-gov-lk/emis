<div>
    <div class="antialiased min-h-screen">
        {{-- Main Dual-Mode Card (Read-Only Container) --}}
        <div class="bg-white dark:bg-gray-800 p-4 rounded-b-lg">

            {{-- Main Content Grid --}}
            <div class="space-y-6">
                @if ($employee->civil_status_id != 'C01')
                    <div class="">
                        {{-- 1. Personal & Socio-Cultural Details --}}
                        <section class="mb-4">
                            <div class="mb-3">
                                <div class="flex items-baseline justify-between py-2">
                                    <h2 class="text-lg font-bold text-gray-800 dark:text-gray-200">
                                        Spouse List
                                    </h2>
                                    @if ($canCreate)
                                        <flux:modal.trigger name="add-spouse-info">
                                            <flux:button>Add spouse</flux:button>
                                        </flux:modal.trigger>
                                    @endif
                                </div>
                                <flux:separator variant="subtle" />
                            </div>
                            <div class="bg-white">

                                {{-- Responsive Table Container --}}
                                <div class="overflow-x-auto">
                                    {{-- Table Structure --}}
                                    <table class="min-w-full divide-y divide-gray-200">

                                        {{-- Table Header --}}
                                        <thead class="bg-gray-50">
                                            <tr>
                                                <th scope="col"
                                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    Spouse names
                                                </th>
                                                <th scope="col"
                                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    Date of birth
                                                </th>
                                                <th scope="col"
                                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    Married date
                                                </th>
                                                <th scope="col"
                                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    Married cf No.
                                                </th>
                                                <th scope="col"
                                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    Status
                                                </th>
                                                <th scope="col"
                                                    class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    Action
                                                </th>
                                            </tr>
                                        </thead>

                                        {{-- Table Body (Using Blade for dynamic data) --}}
                                        <tbody class="bg-white divide-y divide-gray-200">
                                            {{-- Example static data for demonstration. In Blade, you'd use @foreach ($qualifications as $qualification) --}}
                                            @forelse ($familyList as $data)
                                                {{-- Row 1: Master's Degree --}}
                                                <tr class="hover:bg-indigo-50/50">
                                                    <td
                                                        class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                                        <div>
                                                            <p>
                                                                <span>
                                                                    {{ $data->getSpousInfo($employee->people_id)->title->title_name }}
                                                                    {{ $data->getSpousInfo($employee->people_id)->name_with_initials }}
                                                                </span><br />
                                                                <span class=" text-sm text-gray-400">
                                                                    NIC:
                                                                    {{ $data->getSpousInfo($employee->people_id)->nic }}
                                                                </span>
                                                            </p>
                                                        </div>
                                                    </td>
                                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                                        {{ $data->getSpousInfo($employee->people_id)->date_of_birth }}
                                                    </td>
                                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                                        {{ $data->married_date }}
                                                    </td>
                                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                                        {{ $data->married_cf_no }}
                                                    </td>
                                                    <td
                                                        class="px-6 py-4 whitespace-nowrap text-sm text-green-600 font-semibold">
                                                        {{ $data->active_status == 1 ? 'Active' : 'Inactive' }}
                                                    </td>
                                                    <td
                                                        class="px-6 py-4 text-right whitespace-nowrap text-sm text-green-600 font-semibold">
                                                        @if ($canCreate)
                                                            <flux:button
                                                                wire:click="openChildModal('{{ $data->family_id }}')"
                                                                icon="users" variant="subtle" size="sm">Add Child</flux:button>
                                                        @endif
                                                        @if ($canDelete)
                                                            <flux:button icon="trash" variant="subtle" size="sm"
                                                                wire:click="deleteSpouse('{{ $data->family_id }}')"
                                                                onclick="confirm('Are you sure you want to delete this record?') || event.stopImmediatePropagation()" />
                                                            @endif
                                                    </td>
                                                </tr>

                                            @empty
                                                <tr class="bg-white">
                                                    <td colspan="4"
                                                        class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">
                                                        No spouses have been added yet.
                                                    </td>
                                                </tr>
                                            @endforelse

                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </section>

                        {{-- 1. Personal & Socio-Cultural Details --}}
                        <section>
                            <div class="my-6">
                                <div class="flex items-baseline justify-between py-2">
                                    <h2 class="text-lg font-bold text-gray-800 dark:text-gray-200">
                                        Children's list
                                    </h2>
                                </div>
                                <flux:separator variant="subtle" />
                            </div>
                            <div class="bg-white">

                                {{-- Responsive Table Container --}}
                                <div class="overflow-x-auto">
                                    {{-- Table Structure --}}
                                    <table class="min-w-full divide-y divide-gray-200">

                                        {{-- Table Header --}}
                                        <thead class="bg-gray-50">
                                            <tr>
                                                <th scope="col"
                                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    Children names
                                                </th>
                                                <th scope="col"
                                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    Date of birth
                                                </th>
                                                <th scope="col"
                                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    Gender
                                                </th>
                                                <th scope="col"
                                                    class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    Brith cf No.
                                                </th>
                                                <th scope="col"
                                                    class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                    Action
                                                </th>
                                            </tr>
                                        </thead>

                                        {{-- Table Body (Using Blade for dynamic data) --}}
                                        <tbody class="bg-white divide-y divide-gray-200">
                                            {{-- Example static data for demonstration. In Blade, you'd use @foreach ($qualifications as $qualification) --}}

                                            {{-- Row 1: Master's Degree --}}
                                            @forelse($familyMemberList as $data)
                                                <tr class="hover:bg-indigo-50/50">
                                                    <td
                                                        class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                                        {{ $data->child_name }}
                                                    </td>
                                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                                        {{ $data->date_of_birth }}
                                                    </td>
                                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                                        {{ $data->gender->gender_name }}
                                                    </td>
                                                    <td
                                                        class="px-6 py-4 whitespace-nowrap text-sm text-green-600 font-semibold">
                                                        {{ $data->birth_fc_no }}
                                                    </td>
                                                    <td
                                                        class="px-6 py-4 text-right whitespace-nowrap text-sm text-green-600 font-semibold">
                                                        @if ($canDelete)
                                                            <flux:button icon="trash" variant="subtle" size="sm"
                                                                wire:click="deleteChild('{{ $data->id }}')"
                                                                onclick="confirm('Are you sure you want to delete this record?') || event.stopImmediatePropagation()" />
                                                        @endif
                                                    </td>
                                                </tr>

                                            @empty
                                                <tr class="bg-white">
                                                    <td colspan="4"
                                                        class="px-6 py-4 whitespace-nowrap text-center text-sm text-gray-500">
                                                        No data have been added yet.
                                                    </td>
                                                </tr>
                                            @endforelse

                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </section>
                    </div>
                @else
                    <p class=" text-gray-600">Your civil status is single. </p>
                @endif

                {{-- 4. Audit Data (NIC Hash) --}}
                <section class="pt-4 border-t border-gray-200 dark:border-gray-700">
                    <p class="text-xs font-mono text-gray-500 dark:text-gray-600">
                        **NIC Hash (System Key):** {{ $employee->nic_hash }}
                    </p>
                </section>

            </div>

        </div>
    </div>

    {{-- Edit general information --}}
    @if ($canCreate)
        <flux:modal wire:model="showModalSpouseReg" name="add-spouse-info" class="md:w-150">
            <div class="space-y-6">
                <div>
                    <flux:heading size="lg">Spouse Register</flux:heading>
                    <flux:text class="mt-2">Make changes to your personal details.
                </flux:text>
            </div>

            <div>
                @if (session('error'))
                    <x-alert type="error" dismissible class="mb-4">
                        {{ session('error') }}
                    </x-alert>
                @endif

                @if (session('warning'))
                    <x-alert type="warning" dismissible class="mb-4">
                        {{ session('warning') }}
                    </x-alert>
                @endif

                @if (session('info'))
                    <x-alert type="info" dismissible class="mb-4">
                        {{ session('info') }}
                    </x-alert>
                @endif
            </div>

            <form wire:submit.prevent="spouseReg">
                @csrf
                <div class="mt-6 max-w-xl space-y-4">

                    <flux:field label="National Identity Card (NIC)">

                        <div class="flex items-end gap-2">
                            <flux:input id="nic" name="nic" wire:model.live="nic" placeholder="Enter NIC"
                                class="w-full" />

                            <flux:button icon="check" variant="primary" wire:click="checkNIC"
                                class="whitespace-nowrap">
                                Check
                            </flux:button>
                        </div>

                        <!-- IMPORTANT: error MUST be inside flux:field, after the input -->
                        @error('nic')
                            <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
                        @enderror

                    </flux:field>


                    @if ($isCheckNIC)
                        @if ($isPeopleFound)
                            <div class=" p-2 bg-gray-100">
                                <p>
                                    <span>This NIC number is already registered in the information system. If the
                                        information is correct, follow the next steps.</span><br />
                                    <span class=" text-xs">මෙම NIC අංකය මේ වනවිටත් තොරතුරු පද්ධතියේ ලියාපදිංචි වී පවතී. තොරතුරු
                                        නිවැරදිනම් ඉදිරි පියවර අනුගමනය කරන්න.</span>
                                </p>
                                <div class=" mt-3">
                                    <p>NIC: {{ $peopleData->nic }}</p>
                                    <p>Name: {{ $peopleData->name_with_initials }}</p>
                                    <p>Date of Birth: {{ $peopleData->date_of_birth }}</p>
                                </div>
                            </div>
                        @else
                            <div class="mt-6 max-w-xl space-y-4">
                                <div class="flex w-full flex-col md:flex-row gap-4">
                                    <div class="w-1/5">
                                        <flux:field>
                                            <flux:select label="Title" wire:model.live="title">
                                                <option value="">Select</option>
                                                @foreach ($titleOptions as $data)
                                                    <option value="{{ $data->title_id }}">{{ $data->title_name }}
                                                    </option>
                                                @endforeach
                                            </flux:select>
                                        </flux:field>
                                    </div>

                                    <div class="w-4/5">
                                        <flux:field>
                                            <flux:input label="Full Name" wire:model.live="fullName"
                                                placeholder="Enter full name" />
                                        </flux:field>
                                    </div>
                                </div>

                                <div class="flex gap-4">
                                    <!-- Gender -->
                                    <div class="w-1/2">
                                        <flux:field>
                                            <flux:select label="Gender" wire:model.live="gender">
                                                <option value="">Select</option>
                                                @foreach ($genderOptions as $data)
                                                    <option value="{{ $data->gender_id }}">{{ $data->gender_name }}
                                                    </option>
                                                @endforeach
                                            </flux:select>
                                        </flux:field>
                                    </div>

                                    <!-- Birthday -->
                                    <div class="w-1/2">
                                        <flux:field>
                                            <flux:input type="date" label="Birthday" wire:model.live="birthday" />
                                        </flux:field>
                                    </div>
                                </div>

                                <div class="flex flex-col md:flex-row gap-4">
                                    <!-- Ethnicity -->
                                    <div class="md:w-1/2 w-full">
                                        <flux:field>
                                            <flux:select label="Ethnicity" wire:model.live="ethnicity">
                                                <option value="">Select</option>
                                                @foreach ($ethnicityOptions as $data)
                                                    <option value="{{ $data->ethnicity_id }}">
                                                        {{ $data->ethnicity_name }}
                                                    </option>
                                                @endforeach
                                            </flux:select>
                                        </flux:field>
                                    </div>

                                    <!-- Religion Status -->
                                    <div class="md:w-1/2 w-full">
                                        <flux:field>
                                            <flux:select label="Religion" wire:model.live="religion">
                                                <option value="">Select Religion</option>
                                                @foreach ($religionOptions as $data)
                                                    <option value="{{ $data->religion_id }}">
                                                        {{ $data->religion_name }}
                                                    </option>
                                                @endforeach
                                            </flux:select>
                                        </flux:field>
                                    </div>
                                </div>

                                <flux:field>
                                    <flux:input label="Contact" wire:model.live="contact"
                                        placeholder="Enter Contact (10 digits)" />
                                </flux:field>

                                <flux:field>
                                    <flux:input label="Email" type="email" wire:model.live="email"
                                        placeholder="Enter email" />
                                </flux:field>
                            </div>
                        @endif

                        <div class="flex gap-4">
                            <!-- Gender -->
                            <div class="w-1/2">
                                <flux:field>
                                    <flux:input type="date" label="Married date" wire:model.live="marriedDate" />
                                </flux:field>
                            </div>

                            <!-- Birthday -->
                            <div class="w-1/2">
                                <flux:field>
                                    <flux:input type="text" label="Married certifacate no"
                                        wire:model.live="marriedCfNo" />
                                </flux:field>
                            </div>
                        </div>

                        <div class="flex mt-4">
                            <flux:spacer />
                            <flux:button type="submit" variant="primary">Save changes</flux:button>
                        </div>
                    @endif
                </div>


            </form>
        </div>
    </flux:modal>
    @endif

    @if ($canCreate)
        <flux:modal wire:model="showModalChildReg" name="reg-children" class="md:w-100">
            <div class="space-y-4">
                <div>
                    <flux:heading size="lg">Children's register form</flux:heading>
                <flux:text class="mt-2">Make changes to your family details.</flux:text>
                {{-- <p>{{$family_id}}</p> --}}
            </div>

            <div>
                @if (session('error'))
                    <x-alert type="error" dismissible class="mb-4">
                        {{ session('error') }}
                    </x-alert>
                @endif

                @if (session('warning'))
                    <x-alert type="warning" dismissible class="mb-4">
                        {{ session('warning') }}
                    </x-alert>
                @endif

                @if (session('info'))
                    <x-alert type="info" dismissible class="mb-4">
                        {{ session('info') }}
                    </x-alert>
                @endif
            </div>

            <form wire:submit.prevent="childReg" class="space-y-4">
                @csrf

                <flux:input label="Full name" wire:model.live="childName" placeholder="Name" />

                <flux:input label="Date of birth" wire:model.live="childDob" type="date" />

                <flux:field>
                    <flux:select label="Gender" wire:model.live="childGender">
                        <option value="">Select</option>
                        @foreach ($genderOptions as $data)
                            <option value="{{ $data->gender_id }}">{{ $data->gender_name }}</option>
                        @endforeach
                    </flux:select>
                </flux:field>

                <flux:input label="Birth certificate number" wire:model.live="birthCertificateNo" placeholder="254755" />

                <flux:field>
                    <flux:select label="Healthy?" wire:model.live="chailHealthCondition">
                        <option value="">Select Health Condition</option>
                        @foreach ($healthConditionOptions as $value => $label)
                            <option value="{{ $value }}">{{ $label }}</option>
                        @endforeach
                    </flux:select>
                </flux:field>

                <div class="flex">
                    <flux:spacer />

                    <flux:button type="submit" variant="primary">Save changes</flux:button>
                </div>
            </form>
        </div>
    </flux:modal>
    @endif
</div>
