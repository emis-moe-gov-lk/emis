<div>
    <section>
        <div class="mb-3">
            <div class="flex items-baseline justify-between py-2">
                <h2 class="text-lg font-bold text-gray-800 dark:text-gray-200">
                    Location Information
                </h2>
                @if($canEdit)
                    <flux:modal.trigger name="edit-location-info">
                        <flux:button>Edit</flux:button>
                    </flux:modal.trigger>
                @endif
            </div>
            <flux:separator variant="subtle" />
        </div>
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">

            {{-- District --}}
            <div class="p-2 bg-white dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">District
                </p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->district->district_name }}</p>
            </div>

            {{-- GN Division --}}
            <div class="p-2 bg-white dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">GN
                    Division</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                   {{ $employee->gnDivision->gn_division_code ?? '' }} : {{ $employee->gnDivision->gn_division_name ?? 'N/A' }}</p>
            </div>
        </div>

        {{-- Full Address Block --}}
        <div class="mt-4 p-3 bg-gray-100 dark:bg-gray-700 rounded-lg border border-gray-200 dark:border-gray-600 mb-4">
            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Permanent
                Address</p>
            <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                {{ $employee->address_line1 }}<br>
                @if ($employee->address_line2)
                    {{ $employee->address_line2 }}<br>
                @endif
                @if ($employee->address_line3)
                    {{ $employee->address_line3 }}<br>
                @endif
                <span class="font-bold">{{ $employee->postal_code }}</span>
            </p>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">

            {{-- District --}}
            <div class="p-2 bg-white dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Latitude</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->latitude ?? 'N/A'}}</p>
            </div>

            {{-- GN Division --}}
            <div class="p-2 bg-white dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Longitude</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                   {{ $employee->longitude ?? 'N/A'}}</p>
            </div>
        </div>

    </section>

    @if($canEdit)
        {{-- Edit contact information --}}
        <flux:modal wire:model="showModalLocationInfo" name="edit-location-info" class="md:w-150">

            <div class="space-y-4">
                <div>
                    <flux:heading size="lg">Update profile</flux:heading>
                    <flux:text class="mt-2">Make changes to your personal details.
                    </flux:text>
                </div>

                <form wire:submit.prevent="editLocationInfo" class="space-y-4">
                    <flux:field>
                        <flux:select label="District" wire:model.live="district" placeholder="Select District">
                            <option value="">Select</option>
                            @foreach ($districtOption as $data)
                                <option value="{{ $data->district_id }}">{{ $data->district_name }}</option>
                            @endforeach
                        </flux:select>
                    </flux:field>

                    <flux:field>
                        <flux:select label="Divisional Secretary office" wire:model.live="divisionalDecretaryOffice"
                            placeholder="Select Divisional Secretary office">
                            <option value="">Select</option>
                            @foreach ($divisionalSecretaryofficeOption as $data)
                                <option value="{{ $data->dso_id }}">{{ $data->dso_name }}</option>
                            @endforeach
                        </flux:select>
                    </flux:field>

                    <flux:field>
                        <flux:select label="GN Division" wire:model.live="gnDivision" placeholder="Select GN Division">
                            <option value="">Select</option>
                            @foreach ($gnDivisionOption as $data)
                                <option value="{{ $data->gn_division_id }}">({{ $data->gn_division_code }}) -
                                    {{ $data->gn_division_name }}</option>
                            @endforeach
                        </flux:select>
                    </flux:field>

                    <flux:field>
                        <flux:input label="Address Line 1" wire:model.live="addressLine1"
                            placeholder="Enter address line 1" />
                    </flux:field>

                    <flux:field>
                        <flux:input label="Address Line 2" wire:model.live="addressLine2"
                            placeholder="Enter address line 2" />
                    </flux:field>

                    <div class="flex flex-col md:flex-row gap-4">
                        <!-- Address Line 3 -->
                        <div class="md:w-3/4 w-full">
                            <flux:field>
                                <flux:input label="Address Line 3" wire:model.live="addressLine3"
                                    placeholder="Enter address line 3" />
                            </flux:field>
                        </div>

                        <!-- Postal Code -->
                        <div class="md:w-1/4 w-full">
                            <flux:field>
                                <flux:input label="Postal Code" wire:model.live="postalCode"
                                    placeholder="Enter postal code" />
                            </flux:field>
                        </div>
                    </div>

                    <div class="flex flex-col md:flex-row gap-4">
                        <!-- latitude -->
                        <div class="md:w-1/2 w-full">
                            <flux:field>
                                <flux:input label="Latitude" wire:model.live="latitude"
                                    placeholder="Enter latitude (optional)" />
                            </flux:field>
                        </div>

                        <!-- longitude -->
                        <div class="md:w-1/2 w-full">
                            <flux:field>
                                <flux:input label="Longitude" wire:model.live="longitude"
                                    placeholder="Enter longitude (optional)" />
                            </flux:field>
                        </div>
                    </div>

                    <div class="flex mt-4">
                        <flux:spacer />
                        <flux:button type="submit" variant="primary">Save changes</flux:button>
                    </div>
                </form>
            </div>
        </flux:modal>
    @endcan
</div>
