<div>
    <div>
        <div>
            <flux:heading size="lg">{{ __('Update Profile Request') }}</flux:heading>
            <flux:text class="mt-2">{{ __('Please confirm profile update request.') }}</flux:text>
        </div>

        <p class="text-sm text-gray-500 font-bold">Request Ref: {{ $complaint?->complaint_request_ref ?? 'No reference' }}</p>

        @php
            $req = $complaint->requested_changes ?? [];
        @endphp

        <p class="text-sm text-gray-500">
            Subject: <span class="font-bold text-blue-500">{{ $req['subject'] ?? 'No subject' }}</span> <br>
            Complaint: <span class="font-bold text-red-500">{{ $req['complaint'] ?? 'No complaint' }}</span>
        </p>

        <div class="mb-4">
            @if (session('error'))
                <x-alert type="error" dismissible class="mb-4">{{ session('error') }}</x-alert>
            @endif

            @if (session('warning'))
                <x-alert type="warning" dismissible class="mb-4">{{ session('warning') }}</x-alert>
            @endif

            @if (session('info'))
                <x-alert type="info" dismissible class="mb-4">{{ session('info') }}</x-alert>
            @endif
        </div>

        <form wire:submit.prevent="submit" class="space-y-6">
        @csrf
            <flux:field>
                <flux:select label="Response" wire:model.live="response">
                    <option value="">Select</option>
                    @foreach ($responseOption as $key => $data)
                        <option value="{{ $key }}">{{ $data }}</option>
                    @endforeach
                </flux:select>
            </flux:field>

            <flux:field>
                <flux:select label="Reply" wire:model.live="reply">
                    <option value="">Select</option>
                    @foreach ($replyOption as $key => $data)
                        <option value="{{ $key }}">{{ $data }}</option>
                    @endforeach
                </flux:select>
            </flux:field>

            <div class="flex">
                <flux:spacer />
                <flux:button type="submit" variant="primary">{{ __('Confirm') }}</flux:button>
            </div>
        </form>
    </div>    
</div>
