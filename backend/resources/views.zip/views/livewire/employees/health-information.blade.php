<div>
    <section>
        <div class="mb-3">
            <div class="flex items-baseline justify-between py-2">
                <h2 class="text-lg font-bold text-gray-800 dark:text-gray-200">
                    Health Information
                </h2>
                @if($canEdit)
                    <flux:modal.trigger name="edit-profile-health-info">
                        <flux:button>Edit</flux:button>
                    </flux:modal.trigger>
                @endif
            </div>
            <flux:separator variant="subtle" />
        </div>

        <div class="grid grid-cols-3 gap-4">

            {{-- Blood Group --}}
            <div class="p-2 border-l-3 border-red-400 bg-red-50 dark:bg-gray-700 shadow-sm rounded-r-md">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Blood
                    Group</p>
                <p class="text-sm font-bold text-red-600 dark:text-red-400">
                    {{ $employee->bloodGroup->blood_group }}</p>
            </div>

            {{-- Health Condition --}}
            <div
                class="p-2 bg-gray-50 dark:bg-gray-700 rounded-md shadow-sm border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Overall
                    Condition</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                <p>{{ $employee->health_status }}</p>
            </div>

            {{-- Health Problem --}}
            <div
                class="p-2 bg-gray-50 dark:bg-gray-700 rounded-md shadow-sm border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Known
                    Problems</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->health_problem ?? 'None' }}</p>
            </div>

        </div>
    </section>

    @if($canEdit)
        {{-- Edit health information --}}
        <flux:modal wire:model="showModalHealthInfo" name="edit-profile-health-info" class="md:w-96">
            <div class="space-y-6">
                <div>
                    <flux:heading size="lg">Health Information</flux:heading>
                    <flux:text class="mt-2">Make changes to your health details.
                    </flux:text>
                </div>
                <form wire:submit.prevent="editHealthInfo">
                    @csrf
                    <div class="mt-6 max-w-xl space-y-4">

                        <flux:field>
                            <flux:select label="Blood Group" wire:model.live="bloodGroup">
                                <option value="">Select</option>
                                @foreach ($bloodGroupOptions as $data)
                                    <option value="{{ $data->blood_group_id }}">{{ $data->blood_group }}</option>
                                @endforeach
                            </flux:select>
                        </flux:field>

                        <!-- Health Condition -->
                        <div class="w-full">
                            <flux:field>
                                <flux:select label="Healthy?" wire:model.live="healthCondition">
                                    <option value="">Select Health Condition</option>
                                    @foreach ($healthConditionOptions as $value => $label)
                                        <option value="{{ $value }}">{{ $label }}</option>
                                    @endforeach
                                </flux:select>
                            </flux:field>
                        </div>


                        <!-- Health Problem -->
                        @if ($healthCondition == false)
                            <div class="w-full">
                                <flux:field>
                                    <flux:textarea label="Please provide details of the health problem."
                                        wire:model.live="healthProblem" placeholder="Enter health problem details here..."
                                        rows="4" />
                                </flux:field>
                            </div>
                        @endif

                    </div>

                    <div class="flex mt-4">
                        <flux:spacer />
                        <flux:button type="submit" variant="primary">Save changes</flux:button>
                    </div>
                </form>
            </div>
        </flux:modal>
    @endif
</div>
