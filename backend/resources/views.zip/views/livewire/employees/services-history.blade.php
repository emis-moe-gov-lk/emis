<div>
    <section>
        <div class="mb-3">
            <div class="flex items-baseline justify-between py-2">
                <h2 class="text-lg font-bold text-gray-800 dark:text-gray-200">
                    Previous Service-related information
                </h2>
                @if ($canCreate)
                    <flux:modal.trigger name="add-service-record">
                        <flux:button icon="plus" size="sm">Previous Record
                        </flux:button>
                    </flux:modal.trigger>
                @endif
            </div>
        </div>
        <div class="bg-white">

            {{-- Responsive Table Container --}}
            <div class="overflow-x-auto">
                {{-- Table Structure --}}
                <table class="min-w-full divide-y divide-gray-200">

                    {{-- Table Header --}}
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Position
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Service
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Grade/Rank
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Start Date
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                End date
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Action
                            </th>
                        </tr>
                    </thead>

                    {{-- Table Body (Using Blade for dynamic data) --}}
                    <tbody class="bg-white divide-y divide-gray-200">
                        {{-- Example static data for demonstration. In Blade, you'd use @foreach ($qualifications as $qualification) --}}

                        {{-- Row 1: Master's Degree --}}
                        @forelse ($serviceUpdate->where('updated_type', '!=', '1') as $item)
                            <tr class="hover:bg-indigo-50/50 uppercase">
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                    {{ $item->position->position_name }}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                    {{ $item->service->service_name }}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                    {{ $item->rank->rank_name }}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                    {{ $item->appoint_date }}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                    {{ $item->end_date }}
                                </td>
                                <td
                                    class="px-6 py-4 whitespace-nowrap text-sm font-semibold justify-end flex gap-1">
                                    @if ($canDelete)
                                        {{-- Delete button triggers Livewire method --}}
                                        <flux:button icon="trash" variant="subtle" size="sm"
                                            wire:click="deleteServiceRecord({{ $item->id }})"
                                            onclick="confirm('Are you sure you want to delete this record?') || event.stopImmediatePropagation()" />
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6"
                                    class="px-6 py-4 whitespace-nowrap text-sm text-gray-600 text-center">
                                    No previous service records found.
                                </td>
                            </tr>
                        @endforelse

                    </tbody>
                </table>
            </div>
        </div>

    </section>

    <section>
        <div class="mt-4">
            <div class="flex items-baseline justify-between py-2">
                <h2 class="text-lg font-bold text-gray-800 dark:text-gray-200">
                    Previous working place
                </h2>
            </div>
        </div>
        <div class="bg-white">

            {{-- Responsive Table Container --}}
            <div class="overflow-x-auto">
                {{-- Table Structure --}}
                <table class="min-w-full divide-y divide-gray-200">

                    {{-- Table Header --}}
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Working Place & Address
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Appointed date
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Release date
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Service period
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Action
                            </th>
                        </tr>
                    </thead>

                    {{-- Table Body (Using Blade for dynamic data) --}}
                    <tbody class="bg-white divide-y divide-gray-200">
                        @forelse ($serviceUpdate->where('updated_type', 1) as $item)
                            <tr class="hover:bg-indigo-50/50 uppercase">
                                <td class="px-6 py-4 whitespace-normal">
                                    <p class="text-sm font-medium text-gray-900">
                                        <span>{{ $item->workplace->office_name ?? 'N/A' }}</span><br />
                                        <span>{{ $item->workplace->address ?? 'N/A' }}</span>
                                    </p>
                                </td>

                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                    {{ $item->appoint_date }}
                                </td>

                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                    {{ $item->end_date }}
                                </td>

                                <td class="px-6 py-4 whitespace-nowrap text-sm text-green-600 font-semibold">
                                    {{ $item->service_period }}
                                </td>

                                <td class="px-6 py-4 whitespace-nowrap text-sm justify-end flex gap-1">
                                    @if ($canDelete)
                                        <flux:button icon="trash" variant="subtle" size="sm"
                                            wire:click="deleteServiceRecord({{ $item->id }})"
                                            onclick="confirm('Are you sure you want to delete this record?') || event.stopImmediatePropagation()" />
                                    @endif
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5"
                                    class="px-6 py-4 whitespace-nowrap text-sm text-gray-600 text-center">
                                    No previous working place records found.
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>

    </section>

    {{-- Modal Section --}}
    @if ($canCreate)
        {{-- Add Service Record --}}
        <flux:modal name="add-service-record" class="md:w-150" wire:model="showModal" dismissible="false">
            <div class="space-y-6">
                <div>
                    <flux:heading size="lg">Add Previous Record</flux:heading>
                    <flux:text class="mt-2">Enter the details of the previous service record.
                    </flux:text>
                </div>

                <form wire:submit.prevent="saveServiceRecord" class="space-y-4">

                    <flux:select label="What is update type" wire:model.live="recordType" class="w-full">
                        <flux:select.option value="">Select type</flux:select.option>
                        <flux:select.option value="0">Position</flux:select.option>
                        <flux:select.option value="1">Grade update</flux:select.option>
                        <flux:select.option value="2">Previous workplace</flux:select.option>
                    </flux:select>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
                        <flux:select label="Service" wire:model.live="service" class="w-full">
                            <flux:select.option value="">Select Service</flux:select.option>
                            @foreach ($userServicesOptions as $service)
                                <flux:select.option value="{{ $service->service_id }}">
                                    {{ $service->service->service_name }}
                                </flux:select.option>
                            @endforeach
                        </flux:select>

                        <flux:select label="Grade" wire:model.live="rank" class="w-full">
                            <flux:select.option value="">Select Rank</flux:select.option>
                            @foreach ($ranksOptions as $rank)
                                <flux:select.option value="{{ $rank->rank_id }}">
                                    {{ $rank->rank_name }}
                                </flux:select.option>
                            @endforeach
                        </flux:select>
                    </div>

                    <flux:select label="Position" wire:model.live="position" class="w-full">
                        <flux:select.option value="">Select Rank</flux:select.option>
                        @foreach ($positionOption as $position)
                            <flux:select.option value="{{ $position->position_id }}">
                                {{ $position->position_name }}
                            </flux:select.option>
                        @endforeach
                    </flux:select>

                    <flux:select label="Working Place Level" wire:model.live="officeLevel">
                        <option value="">Select</option>
                        @foreach ($officeLevelOption as $level)
                            <option value="{{ $level->office_level_id }}">{{ $level->office_level_name }}</option>
                        @endforeach
                    </flux:select>

                    @if ($officeLevel == 'OLID006')
                        <flux:select label="Zonal Education Office" wire:model.live="zonalEducationOffice">
                            <option value="">Select</option>
                            @foreach ($zonalEducationOfficeOption as $zone)
                                <option value="{{ $zone->workplace_id }}">{{ $zone->short_name }}
                                </option>
                            @endforeach
                        </flux:select>

                        <flux:select label="Institution Category" wire:model.live="institutionCategory">
                            <option value="">Select</option>
                            @foreach ($institutionCategoryOption as $data)
                                <option value="{{ $data->institution_category_id }}">
                                    {{ $data->institution_category_name }}</option>
                            @endforeach
                        </flux:select>
                    @endif

                    <flux:select label="Working Place" wire:model.live="workingPlace">
                        <option value="">Select</option>
                        @foreach ($workingPlaceOption as $office)
                            <option value="{{ $office->workplace_id }}">{{ $office->office_name }}</option>
                        @endforeach
                    </flux:select>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
                        <flux:input label="Appointed Date" type="date" wire:model.live="appointDate" />
                        <flux:input label="Ended Date" type="date" wire:model.live="endedDate" />
                    </div>

                    <div class="flex">
                        <flux:spacer />
                        <flux:button type="submit" variant="primary">Save changes
                        </flux:button>
                    </div>
                </form>
            </div>
        </flux:modal>
    @endif
</div>
