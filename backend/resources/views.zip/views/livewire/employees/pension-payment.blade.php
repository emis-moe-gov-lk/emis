<div>
    <section>
        <div class="mb-3">
            <div class="flex items-baseline justify-between py-2">
                <h2 class="text-lg font-bold text-gray-800 dark:text-gray-200">
                    W&OP & Payment Details
                </h2>
                @if ($canEdit)
                    <flux:modal.trigger name="edit-profile-pension-payment">
                        <flux:button>Edit</flux:button>
                    </flux:modal.trigger>
                @endif
            </div>
            <flux:separator variant="subtle" />
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4 mb-4">

            {{-- Full Name --}}
            <div class="p-2 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">W&OP No</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->appointment->w_op_no ?? 'N/A' }}
                </p>
            </div>

            {{-- Name with Initials --}}
            <div class="p-2 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Pay Sheet No</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->appointment->pay_sheet_no ?? 'N/A' }}</p>
            </div>
        </div>
    </section>

    @if ($canEdit)
    <flux:modal name="edit-profile-pension-payment" class="md:w-96">
        <div class="space-y-6">
            <div>
                <flux:heading size="lg">Update pension and payment details</flux:heading>
                <flux:text class="mt-2">Make changes to your personal details.</flux:text>
            </div>

            <form wire:submit.prevent="updatePensionPayment">
                <div class=" mb-4">
                    <flux:field>
                    <flux:input wire:model.live="wopNo" label="W&OP No" placeholder="Your W&OP No" />
                </flux:field>
                </div>

                <div class=" mb-4">
                    <flux:field>
                    <flux:input wire:model.live="paySheetNo" label="Pay Sheet No" placeholder="Your pay sheet number" />
                </flux:field>
                </div>

                <div class="flex">
                    <flux:spacer />

                    <flux:button type="submit" variant="primary">Save changes</flux:button>
                </div>
            </form>
        </div>
    </flux:modal>
    @endif
</div>
