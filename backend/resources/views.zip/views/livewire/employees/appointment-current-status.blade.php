<div>
    <section>
        <div class="mb-3">
            <div class="flex items-baseline justify-between py-2">
                <div class="items-center justify-center flex gap-2">
                    <flux:badge variant="pill" icon="clock">{{ $employee->currentAppointment->service_years ?? 'N/A' }}</flux:badge>
                    <span class="text-lg font-bold text-gray-800 dark:text-gray-200 ">Appointment current status</span>
                </div>
                @if($canEdit)
                    <flux:modal.trigger name="current-employment-edit">
                        <flux:button icon="pencil-square" size="sm">Edit</flux:button>
                    </flux:modal.trigger>
                @endif
            </div>
            <flux:separator variant="subtle" />
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4 mb-4">

            {{-- Religion --}}
            <div class="p-2 bg-white dark:bg-gray-700 rounded-md shadow-sm border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Service
                </p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->currentAppointment->service->service_name }}</p>
            </div>

            {{-- Ethnicity --}}
            <div class="p-2 bg-white dark:bg-gray-700 rounded-md shadow-sm border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">
                    Current Service Rank</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->currentAppointment->rank->rank_name }}</p>
            </div>

            {{-- Civil Status --}}
            <div class="p-2 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">
                    Appointment Date</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->currentAppointment->appoint_date->format('Y-m-d') }}</p>
            </div>

            {{-- Civil Status --}}
            <div class="p-2 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Appointment/Transfer Letter
                    No</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->currentAppointment->appointment_letter_no }}</p>
            </div>

            {{-- Civil Status --}}
            <div class="p-2 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Position/ Designation</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->currentAppointment->position->position_name ?? 'N/A' }}</p>
            </div>

            {{-- Civil Status --}}
            <div class="p-2 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Last Updated</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->currentAppointment->updated_at->format('Y-m-d') ?? 'N/A' }}</p>
            </div>

        </div>

        <div class="mt-4 p-3 bg-gray-100 dark:bg-gray-700 rounded-lg border border-gray-200 dark:border-gray-600 mb-4">
            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Workplace Name and Address</p>
            <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                @if ($employee->currentAppointment?->workplace?->office()?->census_no)
                    [{{ $employee->currentAppointment?->workplace?->office()?->census_no }}]
                @endif
                {{ $employee->currentAppointment->workplace->office()->name ?? 'N/A' }} <br />
                {{ $employee->currentAppointment->workplace->office()->address ?? 'N/A' }}
            </p>
        </div>

    </section>

    {{-- Update Current Employment --}}
    @if($canEdit)
        <flux:modal name="current-employment-edit" class="md:w-150">
            <div class="space-y-6">
                <div>
                    <flux:heading size="lg">Update Current Employment</flux:heading>
                    <flux:text class="mt-2">Make changes to your current employment details.</flux:text>
                </div>
                <form wire:submit.prevent="save">
                    @csrf
                    <div class=" space-y-6">
                        <div class="flex flex-col md:flex-row gap-4">
                            <!-- Current Appointment Date -->
                            <div class="md:w-1/2 w-full">
                                <flux:field>
                                    <flux:input type="date" label="Current Appointment Date"
                                        wire:model.live="appointmentDate" />
                                </flux:field>
                            </div>

                            <!-- Current Appointment letter number -->
                            <div class="md:w-1/2 w-full">
                                <flux:field>
                                    <flux:input label="Appointment/Transfer Letter No" wire:model.live="appointmentLetterNo"
                                        placeholder="Enter letter number" />
                                </flux:field>
                            </div>
                        </div>

                        <div class="flex flex-col md:flex-row gap-4">
                            <!-- Current Service -->
                            <div class="md:w-1/2 w-full">
                                <flux:field>
                                    <flux:select label="Current Service" wire:model.live="service">
                                        <option value="">Select</option>
                                        @foreach ($userServicesOptions as $service)
                                            <option value="{{ $service->service_id }}">
                                                {{ $service->service_name }}
                                            </option>
                                        @endforeach
                                    </flux:select>
                                </flux:field>
                            </div>

                            <!-- Current Rank -->
                            <div class="md:w-1/2 w-full">
                                <flux:field>
                                    <flux:select label="Current Service Rank" wire:model.live="serviceRank">
                                        <option value="">Select</option>
                                        @foreach ($ranksOptions as $rank)
                                            <option value="{{ $rank->rank_id }}">{{ $rank->rank_name }}</option>
                                        @endforeach
                                    </flux:select>
                                </flux:field>
                            </div>
                        </div>

                        <flux:select label="Position/ Designation" wire:model.live="position">
                            <option value="">Select</option>
                            @foreach ($positionOption as $data)
                                <option value="{{ $data->position_id }}">
                                    {{ $data->position_name }}</option>
                            @endforeach
                        </flux:select>

                        <div class="space-y-6">
                            <flux:select label="Working Place Level" wire:model.live="officeLevel">
                                <option value="">Select</option>
                                @foreach ($officeLevelOption as $level)
                                    <option value="{{ $level->office_level_id }}">{{ $level->office_level_name }}</option>
                                @endforeach
                            </flux:select>

                            @if ($officeLevel == 'OLID006')
                                <flux:select label="Zonal Education Office" wire:model.live="zonalEducationOffice">
                                    <option value="">Select</option>
                                    @foreach ($zonalEducationOfficeOption as $zone)
                                        <option value="{{ $zone->workplace_id }}">{{ $zone->short_name }}
                                        </option>
                                    @endforeach
                                </flux:select>

                                <flux:select label="Institution Category" wire:model.live="institutionCategory">
                                    <option value="">Select</option>
                                    @foreach ($institutionCategoryOption as $data)
                                        <option value="{{ $data->institution_category_id }}">
                                            {{ $data->institution_category_name }}</option>
                                    @endforeach
                                </flux:select>
                            @endif

                            <flux:select label="Working Place" wire:model.live="workingPlace">
                                <option value="">Select</option>
                                @foreach ($workingPlaceOption as $office)
                                    <option value="{{ $office->workplace_id }}">{{ $office->office_name }}</option>
                                @endforeach
                            </flux:select>
                        </div>
                    </div>

                    <div class="flex mt-4">
                        <flux:spacer />

                        <div class="gap-2">
                            <flux:button type="button" wire:click="resetFields">Reset</flux:button>
                            <flux:button type="submit" variant="primary">Save changes</flux:button>
                        </div>
                    </div>

                </form>

            </div>
        </flux:modal>
    @endif
</div>
