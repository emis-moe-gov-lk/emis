<div>
    <form wire:submit.prevent="submit">
        @csrf
        <div class="space-y-6">
            <div>
                <flux:heading size="lg">{{ __('Confirm profile data') }}</flux:heading>
                <flux:text class="mt-2">{{ __('Make changes to your personal details.') }}</flux:text>
            </div>

            <div class="mb-4">
            @if (session('error'))
                <x-alert type="error" dismissible class="mb-4">
                    {{ session('error') }}
                </x-alert>
            @endif

            @if (session('warning'))
                <x-alert type="warning" dismissible class="mb-4">
                    {{ session('warning') }}
                </x-alert>
            @endif

            @if (session('info'))
                <x-alert type="info" dismissible class="mb-4">
                    {{ session('info') }}
                </x-alert>
            @endif
        </div>

        <flux:input label=" {{ __('Password') }}" wire:model.live="password" placeholder="{{ __('Your password') }}" type="password" />

        <div class="flex">
            <flux:spacer />

            <flux:button type="submit" variant="primary">{{ __('Confirm') }}</flux:button>
        </div>
    </form>
</div>
