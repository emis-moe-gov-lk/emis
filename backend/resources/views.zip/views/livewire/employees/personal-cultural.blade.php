<div>
    <section>
        <div class="mb-3">
            <div class="flex items-baseline justify-between py-2">
                <h2 class="text-lg font-bold text-gray-800 dark:text-gray-200">
                    Personal & Cultural
                </h2>
                @if($canEdit)
                    <flux:modal.trigger name="edit-profile-personal-info">
                        <flux:button>Edit</flux:button>
                    </flux:modal.trigger>
                @endcan
            </div>
            <flux:separator variant="subtle" />
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4 mb-4">

            {{-- Full Name --}}
            <div class="p-2 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Full
                    Name</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->full_name }}</p>
            </div>

            {{-- Name with Initials --}}
            <div class="p-2 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Initials
                    With
                    Name</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->name_with_initials }}</p>
            </div>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {{-- DOB --}}
            <div class="p-2 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">D.O.B
                </p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->date_of_birth }}</p>
            </div>

            {{-- Gender --}}
            <div class="p-2 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Gender
                </p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->gender->gender_name }}</p>
            </div>

            {{-- Religion --}}
            <div class="p-2 bg-white dark:bg-gray-700 rounded-md shadow-sm border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Religion
                </p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->religion->religion_name }}</p>
            </div>

            {{-- Ethnicity --}}
            <div class="p-2 bg-white dark:bg-gray-700 rounded-md shadow-sm border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">
                    Ethnicity</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->ethnicity->ethnicity_name }}</p>
            </div>

            {{-- Civil Status --}}
            <div class="p-2 bg-white dark:bg-gray-700 rounded-md shadow-sm border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Civil
                    Status</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->civilStatus->civil_status_name }}</p>
            </div>

        </div>
    </section>

    @if($canEdit)
        {{-- Edit general information --}}
        <flux:modal wire:model="showModalPersonalInfo" name="edit-profile-personal-info" class="md:w-150">
            <div class="space-y-6">
                <div>
                    <flux:heading size="lg">Personal & Cultural</flux:heading>
                    <flux:text class="mt-2">Make changes to your personal details.
                    </flux:text>
                </div>
                <form wire:submit.prevent="editPersonalInfo">
                    @csrf
                    <div class="mt-6 max-w-xl space-y-4">

                        <flux:field>
                            <flux:input label="National Identity Card (NIC)" wire:model.live="nic"
                                placeholder="Enter NIC" />
                        </flux:field>

                        <flux:field>
                            <flux:select label="Title" wire:model.live="title">
                                <option value="">Select</option>
                                @foreach ($titleOptions as $data)
                                    <option value="{{ $data->title_id }}">{{ $data->title_name }}</option>
                                @endforeach
                            </flux:select>
                        </flux:field>

                        <flux:field>
                            <flux:input label="Full Name" wire:model.live="fullName" placeholder="Enter full name" />
                        </flux:field>

                        <div class="flex gap-4">
                            <!-- Gender -->
                            <div class="w-1/2">
                                <flux:field>
                                    <flux:select label="Gender" wire:model.live="gender">
                                        <option value="">Select</option>
                                        @foreach ($genderOptions as $data)
                                            <option value="{{ $data->gender_id }}">{{ $data->gender_name }}</option>
                                        @endforeach
                                    </flux:select>
                                </flux:field>
                            </div>

                            <!-- Birthday -->
                            <div class="w-1/2">
                                <flux:field>
                                    <flux:input type="date" label="Birthday" wire:model.live="birthday" />
                                </flux:field>
                            </div>
                        </div>

                        <div class="flex flex-col md:flex-row gap-4">
                            <!-- Ethnicity -->
                            <div class="md:w-1/2 w-full">
                                <flux:field>
                                    <flux:select label="Ethnicity" wire:model.live="ethnicity">
                                        <option value="">Select</option>
                                        @foreach ($ethnicityOptions as $data)
                                            <option value="{{ $data->ethnicity_id }}">{{ $data->ethnicity_name }}
                                            </option>
                                        @endforeach
                                    </flux:select>
                                </flux:field>
                            </div>

                            <!-- Religion Status -->
                            <div class="md:w-1/2 w-full">
                                <flux:field>
                                    <flux:select label="Religion" wire:model.live="religion">
                                        <option value="">Select Religion</option>
                                        @foreach ($religionOptions as $data)
                                            <option value="{{ $data->religion_id }}">{{ $data->religion_name }}
                                            </option>
                                        @endforeach
                                    </flux:select>
                                </flux:field>
                            </div>
                        </div>

                        <flux:field>
                            <flux:select label="Civil Status" wire:model.live="civilStatus">
                                <option value="">Select</option>
                                @foreach ($civilStatusOptions as $data)
                                    <option value="{{ $data->civil_status_id }}">{{ $data->civil_status_name }}
                                    </option>
                                @endforeach
                            </flux:select>
                        </flux:field>

                    </div>

                    <div class="flex mt-4">
                        <flux:spacer />
                        <flux:button type="submit" variant="primary">Save changes</flux:button>
                    </div>
                </form>
            </div>
        </flux:modal>
    @endcan
</div>
