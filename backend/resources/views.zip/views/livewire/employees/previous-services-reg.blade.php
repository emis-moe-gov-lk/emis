<div>
    <section>
        <div class="mb-3">
            <div class="flex items-baseline justify-between py-2">
                <h2 class="text-lg font-bold text-gray-800 dark:text-gray-200">
                    Previous Service
                </h2>

                @if ($canCreate)
                    <flux:modal.trigger name="add-previous-service">
                        <flux:button icon="plus" size="sm">Previous services
                        </flux:button>
                    </flux:modal.trigger>
                @endif
                
            </div>
        </div>


        <div class="bg-white">

            {{-- Responsive Table Container --}}
            <div class="overflow-x-auto">
                {{-- Table Structure --}}
                <table class="min-w-full divide-y divide-gray-200">

                    {{-- Table Header --}}
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Service
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Grade/Rank
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Appointment Date
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Retainment Date
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Status
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Action
                            </th>
                        </tr>
                    </thead>

                    {{-- Table Body (Using Blade for dynamic data) --}}
                    <tbody class="bg-white divide-y divide-gray-200">
                        {{-- Example static data for demonstration. In Blade, you'd use @foreach ($qualifications as $qualification) --}}

                        {{-- Row 1: Master's Degree --}}
                        @forelse ($employeeServiceList->where('updated_type', '!=', '1') as $item)
                        <tr class="hover:bg-indigo-50/50 uppercase">
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                {{ $item->service->service_name }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                {{ $item->rank->rank_name }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                {{ $item->first_appointment_date->format('Y-m-d') }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                {{ $item->retirement_date->format('Y-m-d') }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                @if ($item->active_status == 1)
                                <flux:badge color="green" icon="check" size="sm">Active</flux:badge>
                                @else
                                <flux:badge color="red" icon="x-mark" size="sm">Inactive</flux:badge>
                                @endif
                            </td>

                                <td class="px-6 py-4 whitespace-nowrap text-sm font-semibold justify-end flex gap-1">
                                    @if ($canDelete)
                                        {{-- Delete button triggers Livewire method --}}
                                        <flux:button icon="trash" variant="subtle" size="sm"
                                            wire:click="deleteServiceRecord({{ $item->id }})"
                                            onclick="confirm('Are you sure you want to delete this record?') || event.stopImmediatePropagation()" />
                                    @endif
                                </td>
                            </tr>
                        @empty
                        <tr>
                            <td colspan="6"
                                class="px-6 py-4 whitespace-nowrap text-sm text-gray-600 text-center">
                                No previous service records found.
                            </td>
                        </tr>
                        @endforelse

                    </tbody>
                </table>
            </div>
        </div>

    </section>

    {{-- Modal Section --}}
    @if ($canCreate)
        {{-- Add Service Record --}}
        <flux:modal name="add-previous-service" class="md:w-150" wire:model="showModal" dismissible="false">
            <div class="space-y-6">
                <div>
                    <flux:heading size="lg">Add Previous Record</flux:heading>
                    <flux:text class="mt-2">Enter the details of the previous service record.
                    </flux:text>
                </div>

            {{-- <div>
                    @if (session('error'))
                        <x-alert type="error" dismissible class="mb-4">
                            {{ session('error') }}
            </x-alert>
            @endif

            @if (session('warning'))
            <x-alert type="warning" dismissible class="mb-4">
                {{ session('warning') }}
            </x-alert>
            @endif

            @if (session('info'))
            <x-alert type="info" dismissible class="mb-4">
                {{ session('info') }}
            </x-alert>
            @endif
        </div> --}}

        <form wire:submit.prevent="saveServiceRecord" class="space-y-4">

            <div class="flex flex-col md:flex-row gap-4">
                <!-- First Appointment Date -->
                <div class="md:w-1/2 w-full">
                    <flux:field>
                        <flux:input type="date" label="First Appointment Date"
                            wire:model.live="firstAppointmentDate" />
                    </flux:field>
                </div>

                <!-- Appointment letter number -->
                <div class="md:w-1/2 w-full">
                    <flux:field>
                        <flux:input label="Appointment Letter No" wire:model.live="appointmentLetterNo"
                            placeholder="Enter letter number" />
                    </flux:field>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
                <flux:select label="Service" wire:model.live="service" class="w-full">
                    <flux:select.option value="">Select Service</flux:select.option>
                    @foreach ($servicesOptions as $service)
                    <flux:select.option value="{{ $service->service_id }}">
                        {{ $service->service_name }}
                    </flux:select.option>
                    @endforeach
                </flux:select>

                <flux:select label="Grade" wire:model.live="rank" class="w-full">
                    <flux:select.option value="">Select Rank</flux:select.option>
                    @foreach ($ranksOptions as $rank)
                    <flux:select.option value="{{ $rank->rank_id }}">
                        {{ $rank->rank_name }}
                    </flux:select.option>
                    @endforeach
                </flux:select>
            </div>

            <flux:select label="Position" wire:model.live="position" class="w-full">
                <flux:select.option value="">Select Rank</flux:select.option>
                @foreach ($positionOption as $position)
                <flux:select.option value="{{ $position->position_id }}">
                    {{ $position->position_name }}
                </flux:select.option>
                @endforeach
            </flux:select>

            <flux:select label="Working Place Level" wire:model.live="officeLevel">
                <option value="">Select</option>
                @foreach ($officeLevelOption as $level)
                <option value="{{ $level->office_level_id }}">{{ $level->office_level_name }}</option>
                @endforeach
            </flux:select>

            @if ($officeLevel == 'OLID006')
            <flux:select label="Zonal Education Office" wire:model.live="zonalEducationOffice">
                <option value="">Select</option>
                @foreach ($zonalEducationOfficeOption as $zone)
                <option value="{{ $zone->workplace_id }}">{{ $zone->short_name }}
                </option>
                @endforeach
            </flux:select>

            <flux:select label="Institution Category" wire:model.live="institutionCategory">
                <option value="">Select</option>
                @foreach ($institutionCategoryOption as $data)
                <option value="{{ $data->institution_category_id }}">
                    {{ $data->institution_category_name }}
                </option>
                @endforeach
            </flux:select>
            @endif

            <flux:select label="Working Place" wire:model.live="workingPlace">
                <option value="">Select</option>
                @foreach ($workingPlaceOption as $office)
                <option value="{{ $office->workplace_id }}">{{ $office->office_name }}</option>
                @endforeach
            </flux:select>

            <div class="flex">
                <flux:spacer />
                <flux:button type="submit" variant="primary">Save changes
                </flux:button>
            </div>
        </form>
</div>
</flux:modal>
@endcan
</div>