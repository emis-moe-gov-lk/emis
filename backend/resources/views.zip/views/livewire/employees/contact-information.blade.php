<div>
    <section>
        <div class="mb-3">
            <div class="flex items-baseline justify-between py-2">
                <h2 class="text-lg font-bold text-gray-800 dark:text-gray-200">
                    Contact
                </h2>
                @if($canEdit)
                    <flux:modal.trigger name="edit-contact-info">
                        <flux:button>Edit</flux:button>
                    </flux:modal.trigger>
                @endif
            </div>
            <flux:separator variant="subtle" />
        </div>
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">

            {{-- Email --}}
            <div class="p-2 bg-white dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Email
                </p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->email }}</p>
            </div>

            {{-- Phone --}}
            <div class="p-2 bg-white dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Phone
                </p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $employee->phone }}</p>
            </div>
    </section>

    @if($canEdit)
        {{-- Edit contact information --}}
        <flux:modal wire:model="showModalContactInfo" name="edit-contact-info" class="md:w-150">

            <div class="space-y-4">
                <div>
                    <flux:heading size="lg">Update profile</flux:heading>
                    <flux:text class="mt-2">Make changes to your personal details.
                    </flux:text>
                </div>

                <form wire:submit.prevent="editContactInfo" class="space-y-4">
                    <flux:field>
                        <flux:input label="Contact" wire:model.live="contact" placeholder="Enter Contact (10 digits)" />
                    </flux:field>

                    <flux:field>
                        <flux:input label="Email" type="email" wire:model.live="email" placeholder="Enter email" />
                    </flux:field>

                    <div class="flex mt-4">
                        <flux:spacer />
                        <flux:button type="submit" variant="primary">Save changes</flux:button>
                    </div>
                </form>
            </div>
        </flux:modal>
    @endcan
</div>
