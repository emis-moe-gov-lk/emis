<div>
    <section>
        <div class="mb-3">
            <div class="flex items-baseline justify-between py-2">
                <h2 class="text-lg font-bold text-gray-800 dark:text-gray-200">
                    Educational qualification
                </h2>
                @if($canCreate)
                    <flux:modal.trigger name="add-qualification">
                        <flux:button icon="plus">Add qualification</flux:button>
                    </flux:modal.trigger>
                @endif
            </div>
            <flux:separator variant="subtle" />
        </div>

        <div class="bg-white">

            {{-- Responsive Table Container --}}
            <div class="overflow-x-auto">
                {{-- Table Structure --}}
                <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">

                    {{-- Table Header --}}
                    <thead class="bg-gray-50 dark:bg-gray-800">
                        <tr>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Degree / Certificate
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Institution
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Date of Completion
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Grade
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                Action
                            </th>
                        </tr>
                    </thead>

                    {{-- Table Body --}}
                    <tbody class="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">

                        @forelse ($qualificationList as $data)
                            <tr class="hover:bg-indigo-50 dark:hover:bg-indigo-900/40">
                                <td
                                    class="px-6 py-4 whitespace-normal break-words text-sm text-gray-700 dark:text-gray-300">
                                    <p class="whitespace-normal break-words">
                                        {{ $data->qualification->qualification }}
                                    </p>
                                </td>

                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                                    {{ $data->institution }}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                                    {{ $data->effective_date }}
                                </td>
                                <td
                                    class="px-6 py-4 whitespace-nowrap text-sm text-green-600 dark:text-green-400 font-semibold">
                                    {{ $data->qualificationGrade->grade ?? ' -- ' }}
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-right">
                                    @if($canDelete)
                                        <div class="flex gap-2 justify-end">
                                            <flux:button icon="trash" variant="subtle" size="sm"
                                                wire:click="delete({{ $data->id }})"
                                                onclick="confirm('Are you sure you want to delete this record?') || event.stopImmediatePropagation()" />
                                        </div>
                                    @endif
                                </td>

                            </tr>
                        @empty
                            <tr class="hover:bg-indigo-50 dark:hover:bg-indigo-900/40">
                                <td colspan="5"
                                    class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-gray-100">
                                    No data
                                </td>
                            </tr>
                        @endforelse

                    </tbody>
                </table>
            </div>

        </div>

    </section>

    @if($canCreate)
    <flux:modal wire:model="showModal" name="add-qualification" class="md:w-150">
        <div class="space-y-6">
            <div>
                <flux:heading size="lg">Update qualification</flux:heading>
                <flux:text class="mt-2">Make changes to your qualification details.
                </flux:text>
            </div>

            <form wire:submit.prevent="save" class="space-y-4">
                <flux:select wire:model.live="qualification" label="Qualification">
                    <flux:select.option value="">Select</flux:select.option>
                    @foreach ($educationQualificationList as $data)
                        <flux:select.option value="{{ $data->qualifications_id }}">
                            {{ $data->qualification }}
                        </flux:select.option>
                    @endforeach
                </flux:select>

                <flux:input label="Institution" wire:model.live="institution"
                    placeholder="University or Institution name" />

                <flux:input label="Effective date" wire:model.live="effectiveDate" type="date" />

                <flux:select wire:model.live="grade" label="Grade">
                    <flux:select.option value="">Select</flux:select.option>
                    @foreach ($gradeOption as $key => $value)
                        <flux:select.option value="{{ $key }}">{{ $value }}
                        </flux:select.option>
                    @endforeach
                </flux:select>

                <flux:textarea rows="2" wire:model.live="description" label="Description"
                    placeholder="Main Subjects and other details" />

                <div class="flex">
                    <flux:spacer />
                    <flux:button type="submit" variant="primary">Save changes</flux:button>
                </div>
            </form>
        </div>
    </flux:modal>
    @endif
</div>
