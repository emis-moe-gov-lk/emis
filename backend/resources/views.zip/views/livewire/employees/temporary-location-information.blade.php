<div>
    <section>
        <div class="mb-3">
            <div class="flex items-baseline justify-between py-2">
                <h2 class="text-lg font-bold text-gray-800 dark:text-gray-200">
                    Temporary Location
                </h2>
                @if($canEdit)
                    <flux:modal.trigger name="edit-temporary-location-info">
                        <flux:button>Edit</flux:button>
                    </flux:modal.trigger>
                @endif
            </div>
            <flux:separator variant="subtle" />
        </div>

        <div class="mt-4 p-3 bg-gray-100 dark:bg-gray-700 rounded-lg border border-gray-200 dark:border-gray-600">
            <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Residential
                Address</p>
            <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                {{ $employee->t_address_line1 }}<br>
                @if ($employee->t_address_line2)
                    {{ $employee->t_address_line2 }}<br>
                @endif
                @if ($employee->t_address_line3)
                    {{ $employee->t_address_line3 }}<br>
                @endif
                <span class="font-bold">{{ $employee->t_postal_code }}</span>
            </p>
        </div>
    </section>

    @if($canEdit)
        {{-- Edit contact information --}}
        <flux:modal wire:model="showModalTemporaryLocationInfo" name="edit-temporary-location-info" class="md:w-150">

            <div class="space-y-4">
                <div>
                    <flux:heading size="lg">Update temporary location</flux:heading>
                    <flux:text class="mt-2">Make changes to your temporary location details (If different from permanent address).
                    </flux:text>
                </div>

                <form wire:submit.prevent="editTemporaryLocationInfo" class="space-y-4">
                    <div class="space-y-4">
                        <flux:field class="text-gray-700 dark:text-gray-300">
                            <flux:input label="Address Line 1" wire:model.live="tAddressLine1"
                                class="bg-white dark:bg-gray-800 text-black dark:text-white border-gray-300 dark:border-gray-600 placeholder-gray-400"
                                placeholder="Enter address line 1" />
                        </flux:field>

                        <flux:field class="text-gray-700 dark:text-gray-300">
                            <flux:input label="Address Line 2" wire:model.live="tAddressLine2"
                                class="bg-white dark:bg-gray-800 text-black dark:text-white border-gray-300 dark:border-gray-600 placeholder-gray-400"
                                placeholder="Enter address line 2" />
                        </flux:field>

                        <div class="flex flex-col md:flex-row gap-4">
                            <div class="md:w-3/4 w-full">
                                <flux:field class="text-gray-700 dark:text-gray-300">
                                    <flux:input label="Address Line 3" wire:model.live="tAddressLine3"
                                        class="bg-white dark:bg-gray-800 text-black dark:text-white border-gray-300 dark:border-gray-600 placeholder-gray-400"
                                        placeholder="Enter address line 3" />
                                </flux:field>
                            </div>

                            <div class="md:w-1/4 w-full">
                                <flux:field class="text-gray-700 dark:text-gray-300">
                                    <flux:input label="Postal Code" wire:model.live="tPostalCode"
                                        class="bg-white dark:bg-gray-800 text-black dark:text-white border-gray-300 dark:border-gray-600 placeholder-gray-400"
                                        placeholder="Enter postal code" />
                                </flux:field>
                            </div>
                        </div>

                    </div>

                    <div class="flex mt-4">
                        <flux:spacer />
                        <flux:button type="submit" variant="primary">Save changes</flux:button>
                    </div>
                </form>
            </div>
        </flux:modal>
    @endcan
</div>
