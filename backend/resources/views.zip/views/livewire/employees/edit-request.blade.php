<div>
    <!-- component -->
    <div class="mx-auto mb-20">
        <div class="flow-root">

            @forelse ($editRequests as $editRequest)
            <ul>
                <li>
                    <div class="relative pb-8">
                        <span class="absolute top-5 left-5 -ml-px h-full w-0.5 bg-gray-200 dark:bg-gray-700" aria-hidden="true"></span>
                        <div class="relative flex items-start space-x-3">
                            <div>
                                <div class="relative px-1">
                                    <div class="h-8 w-8 bg-blue-500 rounded-full ring-8 ring-white dark:ring-gray-900 flex items-center justify-center">
                                        <svg class="text-white h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                                        </svg>
                                    </div>
                                </div>
                            </div>
                            <div class="min-w-0 flex-1 py-0">
                                <div class="text-md text-gray-500 dark:text-gray-400">
                                    <div>
                                        <a href="#" class="font-medium text-gray-900 dark:text-gray-100 mr-2">{{ $editRequest->complaint_request_ref }}</a>

                                        <a href="#"
                                            class="my-0.5 relative inline-flex items-center bg-white dark:bg-gray-800 rounded-full border border-gray-300 dark:border-gray-600 px-3 py-0.5 text-sm">
                                            <div class="absolute flex-shrink-0 flex items-center justify-center">
                                                <span class="h-1.5 w-1.5 rounded-full bg-green-500" aria-hidden="true"></span>
                                            </div>
                                            <div class="ml-3.5 font-medium text-gray-900 dark:text-gray-100">Request/ Complaint</div>
                                        </a>
                                    </div>
                                    <span class="whitespace-nowrap text-sm">{{ $editRequest->created_ago }}</span>
                                </div>
                                <div class="mt-2 text-gray-700 dark:text-gray-300">
                                    <div class="space-y-1">
                                        @if(isset($editRequest->requested_changes['subject']))
                                        <p>
                                            <span class="font-medium text-gray-900 dark:text-gray-100">Subject:</span>
                                            {{ $editRequest->requested_changes['subject'] }}
                                        </p>
                                        @endif
                                        @if(isset($editRequest->requested_changes['complaint']))
                                        <p>
                                            <span class="font-medium text-gray-900 dark:text-gray-100">Complaint:</span>
                                            {{ $editRequest->requested_changes['complaint'] }}
                                        </p>
                                        @endif
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="relative pb-8">
                        <span class="absolute top-5 left-5 -ml-px h-full w-0.5 bg-gray-200 dark:bg-gray-700" aria-hidden="true"></span>
                        <div class="relative flex items-start space-x-3">
                            <div>
                                <div class="relative px-1">
                                    <div class="h-8 w-8 bg-blue-500 rounded-full ring-8 ring-white dark:ring-gray-900 flex items-center justify-center">
                                        <svg class="text-white h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke="currentColor">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                                        </svg>
                                    </div>
                                </div>
                            </div>
                            <div class="min-w-0 flex-1 py-0">
                                <div class="text-md text-gray-500 dark:text-gray-400">
                                    <div>
                                        <a href="#" class="font-medium text-gray-900 dark:text-gray-100 mr-2">{{ $editRequest->getStatusTextAttribute() }}</a>

                                        <a href="#"
                                            class="my-0.5 relative inline-flex items-center bg-white dark:bg-gray-800 rounded-full border border-gray-300 dark:border-gray-600 px-3 py-0.5 text-sm">
                                            <div class="absolute flex-shrink-0 flex items-center justify-center">
                                                <span class="h-1.5 w-1.5 rounded-full bg-green-500" aria-hidden="true"></span>
                                            </div>
                                            <div class="ml-3.5 font-medium text-gray-900 dark:text-gray-100">Reply</div>
                                        </a>
                                    </div>
                                    <span class="whitespace-nowrap text-sm">{{ $editRequest->updated_ago }}</span>
                                </div>
                                <div class="mt-2 text-gray-700 dark:text-gray-300">
                                    <p>
                                        - {{ $editRequest->review_comments }}
                                    </p>
                                    <p class=" text-xs text-gray-500 dark:text-gray-400 italic py-2">
                                        Reviewer :{{ $editRequest->reviewer->title->title_name ?? '' }} {{ $editRequest->reviewer->name_with_initials ?? '' }}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
            @empty
            <p class=" text-sm text-gray-500 dark:text-gray-400">No edit requests found.</p>
            @endforelse


        </div>
    </div>
</div>