<div>
    <section>
        <div class="mb-3">
            <div class="flex items-baseline justify-between py-2">
                <div class="items-center justify-center flex gap-2">
                    <flux:badge variant="pill" icon="academic-cap">
                        {{ $employee->appointment->service->service_name ?? 'N/A' }}
                    </flux:badge>
                    <span class="text-lg font-bold text-gray-800 dark:text-gray-200 ">Teaching Info</span>
                </div>
                @can('teacher.profile.employment.teacher-information.update')
                <flux:modal.trigger name="teacher-data-edit">
                    <flux:button icon="pencil-square" size="sm">Edit</flux:button>
                </flux:modal.trigger>
                @endcan
            </div>
            <flux:separator variant="subtle" />
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4 mb-4">

            {{-- Service --}}
            <div class="p-2 bg-white dark:bg-gray-700 rounded-md shadow-sm border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Teacher catogary
                </p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $teacherData->teacherCategory->name ?? 'N/A' }}
                </p>
            </div>

            {{-- Service Rank --}}
            <div class="p-2 bg-white dark:bg-gray-700 rounded-md shadow-sm border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">
                    Teacher Appointment Type</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $teacherData->teacherType->type_name ?? 'N/A' }}
                </p>
            </div>

            {{-- Appointment Date --}}
            <div class="p-2 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">
                    Medium</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $teacherData->medium->name ?? 'N/A' }}
                </p>
            </div>

            {{-- Appointment Number --}}
            <div class="p-2 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Appointment Subject</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $teacherData->appointmentSubject->name_en ?? 'N/A' }}
                </p>
            </div>

            {{-- Position/ Designation --}}
            <div class="p-2 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Main teaching subject</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $teacherData->mainSubject->name_en ?? 'N/A' }}
                </p>
            </div>

            {{-- Created --}}
            <div class="p-2 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Secondary Subject (Optional)
                </p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $teacherData->secondarySubject->name_en ?? 'N/A' }}
                </p>
            </div>

            {{-- Created --}}
            <div class="p-2 bg-gray-50 dark:bg-gray-700 rounded-md border border-gray-200 dark:border-gray-600">
                <p class="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">Current Teaching
                    Subject(Assigned by School)</p>
                <p class="text-sm font-medium text-gray-900 dark:text-gray-100">
                    {{ $teacherData->currentTeachingSubject->name_en ?? 'N/A' }}
                </p>
            </div>

        </div>

    </section>

    {{-- Update Employment --}}
    @can('teacher.profile.employment.teacher-information.update')
    <flux:modal name="teacher-data-edit" class="md:w-150">
        <div class="space-y-6">
            <div>
                <flux:heading size="lg">Teacher Data</flux:heading>
                <flux:text class="mt-2">Make changes to your teacher details.</flux:text>
            </div>
            <form wire:submit.prevent="save">
                @csrf
                <div class=" space-y-6">
                    <flux:field>
                        <flux:select label="Teacher Type" wire:model.live="teacherType">
                            <option value="">Select</option>
                            @foreach ($teacherTypeOptions as $teacherType)
                            <option value="{{ $teacherType->teacher_types_id }}">
                                {{ $teacherType->type_name }}
                            </option>
                            @endforeach
                        </flux:select>
                    </flux:field>

                    <div class="flex flex-col md:flex-row gap-4">
                        <flux:field class="w-full">
                            <flux:select label="Teacher Category" wire:model.live="teacherCategory">
                                <option value="">Select</option>
                                @foreach ($teacherCategoryOptions as $teacherCategory)
                                <option value="{{ $teacherCategory->categories_id }}">
                                    {{ $teacherCategory->name }}
                                </option>
                                @endforeach
                            </flux:select>
                        </flux:field>

                        <flux:field class="w-full">
                            <flux:select label="Medium of instruction" wire:model.live="medium">
                                <option value="">Select</option>
                                @foreach ($mediumOptions as $medium)
                                <option value="{{ $medium->medium_id }}">
                                    {{ $medium->name }}
                                </option>
                                @endforeach
                            </flux:select>
                        </flux:field>
                    </div>

                    <flux:field class="w-full">
                        <flux:select label="Appointment Subject" wire:model.live="appointmentSubject">
                            <option value="">Select</option>
                            @foreach ($appointmentSubjectOptions as $appointmentSubject)
                            <option value="{{ $appointmentSubject->a_subject_id }}">
                                {{ $appointmentSubject->name_en }}
                            </option>
                            @endforeach
                        </flux:select>
                    </flux:field>

                    <flux:field class="w-full">
                        <flux:select label="Main Subject" wire:model.live="mainSubject">
                            <option value="">Select</option>
                            @foreach ($subjectOptions as $subject)
                            <option value="{{ $subject->subject_id }}">
                                {{ $subject->name_en }}
                            </option>
                            @endforeach
                        </flux:select>
                    </flux:field>

                    <flux:field class="w-full">
                        <flux:select label="Secondary Subject (Optional)" wire:model.live="secondarySubject">
                            <option value="">Select</option>
                            @foreach ($subjectOptions as $subject)
                            <option value="{{ $subject->subject_id }}">
                                {{ $subject->name_en }}
                            </option>
                            @endforeach
                        </flux:select>
                    </flux:field>

                    <flux:field class="w-full">
                        <flux:select label="Current or most Teaching Subject" wire:model.live="currentTeachingSubject">
                            <option value="">Select</option>
                            @foreach ($subjectOptions as $subject)
                            <option value="{{ $subject->subject_id }}">
                                {{ $subject->name_en }}
                            </option>
                            @endforeach
                        </flux:select>
                    </flux:field>
                </div>

                <div class="flex mt-4">
                    <flux:spacer />

                    <div class="gap-2">
                        <flux:button type="button" wire:click="resetFields">Reset</flux:button>
                        <flux:button type="submit" variant="primary">Save changes</flux:button>
                    </div>
                </div>

            </form>

        </div>
    </flux:modal>
    @endcan
</div>