<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Principal Profile') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage principal profile and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-principals.principal-profile-layout :principalid="$id">
        <livewire:employees.family-information :peopleId="$principal->people_id" :canCreate="auth()->user()->can('principal.profile.family.create')" :canDelete="auth()->user()->can('principal.profile.family.delete')"/>
    </x-principals.principal-profile-layout>
</section>
