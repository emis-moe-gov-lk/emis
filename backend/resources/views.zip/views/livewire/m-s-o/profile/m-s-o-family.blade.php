
<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Management Assistant Officer Profile') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Management Assistant Officer profile and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-m-s-o.m-s-o-profile-layout :msoid="$id">
        <livewire:employees.family-information :peopleId="$mso->people_id" :canCreate="auth()->user()->can('mso.profile.family.create')" :canDelete="auth()->user()->can('mso.profile.family.delete')"/>
    </x-m-s-o.m-s-o-profile-layout>
</section>