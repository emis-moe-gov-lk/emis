<div>
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Management Assistant Officer List for') }} {{ Auth::user()->workplace?->office_name ?? 'All Workplaces' }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Management Assistant Officer profile and account') }}
        </flux:subheading>
        <flux:separator variant="subtle" />

        <div>
            @if (session('success'))
            <x-alert type="success" dismissible class="mb-4">
                {{ session('success') }}
            </x-alert>
            @endif

            @if (session('error'))
            <x-alert type="error" dismissible class="mb-4">
                {{ session('error') }}
            </x-alert>
            @endif

            @if (session('warning'))
            <x-alert type="warning" dismissible class="mb-4">
                {{ session('warning') }}
            </x-alert>
            @endif

            @if (session('info'))
            <x-alert type="info" dismissible class="mb-4">
                {{ session('info') }}
            </x-alert>
            @endif
        </div>

        <div class="my-6 flex items-center justify-end gap-3">

            {{-- Search Button (Modal Trigger) --}}
            <flux:modal.trigger name="search-profile">
                <flux:input as="button" placeholder="Search MSO..." icon="magnifying-glass" kbd="⌘K"
                    class="w-48 md:w-60 cursor-pointer transition-all hover:shadow-sm focus:ring-2 focus:ring-blue-500" />
            </flux:modal.trigger>

            {{-- Create Management Assistant Button (Permission Based) --}}
            @can('mso.create')
            <a href="{{ route('mso.create') }}">
                <flux:button icon="plus" color="primary"
                    class="px-4 py-2 font-medium shadow-sm transition-all hover:shadow-md">
                    Create Management Assistant
                </flux:button>
            </a>
            @endcan

            {{-- Create Management Assistant Button (Permission Based) --}}
            @can('mso.bulk.upload')
            <a href="">
                <flux:button icon="plus" color="primary"
                    class="px-4 py-2 font-medium shadow-sm transition-all hover:shadow-md">
                    Bulk Upload Management Assistant
                </flux:button>
            </a>
            @endcan

            {{-- Search Modal --}}
            <flux:modal name="search-profile" class="md:w-[28rem] rounded-xl shadow-lg">
                <div class="space-y-6 p-4">
                    {{-- Header --}}
                    <div class="text-center">
                        <flux:heading size="lg" class="text-gray-800 dark:text-gray-100">
                            Search MSO Profile
                        </flux:heading>
                        <flux:text class="mt-2 text-gray-500 dark:text-gray-400 text-sm">
                            Search for a Management Assistant by
                            <span class="font-semibold text-gray-700 dark:text-gray-300">NIC or email or contact number </span>.
                        </flux:text>
                    </div>

                    {{-- Search Input --}}
                    <div>
                        <flux:input icon="magnifying-glass" wire:model.live="query" placeholder="Type NIC..."
                            class="w-full focus:ring-2 focus:ring-blue-500" />
                    </div>

                    {{-- Results --}}
                    @if (!empty($results) && count($results) > 0)
                    <ul class="divide-y divide-gray-200 dark:divide-gray-700 mt-2">
                        @foreach ($results as $mso)
                        <li
                            class="py-2 px-3 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md cursor-pointer transition">
                            <a href="{{ route('mso.profile.index', $mso->id) }}">
                                <div class="flex justify-between items-center">
                                    <span class="font-semibold text-gray-800 dark:text-gray-100">
                                        {{ $mso['name_with_initials'] }}
                                    </span>
                                    <span class="text-sm text-gray-500 dark:text-gray-400">
                                        {{ $mso['nic'] }}
                                    </span>
                                </div>
                            </a>
                        </li>
                        @endforeach
                    </ul>
                    @elseif(strlen($query) >= 10)
                    <p class="text-sm text-gray-500 dark:text-gray-400 text-center py-2">
                        No Management Assistant found.
                    </p>
                    @endif


                </div>
            </flux:modal>


        </div>

        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200 border rounded-lg overflow-hidden shadow-sm">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wide">
                            Name
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wide">
                            Designation
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wide">
                            Working Place
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wide">
                            Contact
                        </th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wide">
                            Status
                        </th>
                        <th class="px-6 py-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wide">
                            Actions
                        </th>
                    </tr>
                </thead>

                <tbody class="bg-white divide-y divide-gray-200">
                    @forelse($employees as $employee)
                    <tr class="hover:bg-gray-50 transition-colors duration-150">
                        <!-- Name Section -->
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex items-center gap-4">
                                <div class="h-11 w-11 rounded-full overflow-hidden border">
                                    <img class="h-full w-full object-cover"
                                        src="{{ $employee->gender_id == 'G02' ? asset('images/profile_f.png') : asset('images/profile_m.png') }}"
                                        alt="Profile">
                                </div>

                                <div>
                                    <div class="text-sm font-semibold text-gray-900 flex items-center gap-1">
                                        <flux:link href="{{ route('mso.profile.index', $employee->id) }}" variant="ghost">
                                            {{ $employee->title->title_name ?? '' }} {{ $employee->name_with_initials }}
                                        </flux:link>
                                    </div>
                                    <div class="text-xs text-gray-500">
                                        NIC: <span class="font-medium">{{ $employee->nic }}</span>
                                    </div>
                                </div>
                            </div>
                        </td>

                        <!-- Designation Section -->
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900">
                                {{ $employee->currentAppointment?->position?->position_name ?? 'N/A' }}
                            </div>
                            <div class="text-xs text-gray-500">
                                {{ $employee->currentAppointment?->service?->service_name ?? 'N/A' }}
                            </div>
                        </td>

                        <!-- Workplace -->
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="flex flex-col gap-1">
                                <span class="text-sm font-medium text-gray-900">
                                    @php
                                    $office = $employee->currentAppointment?->workplace?->office();
                                    @endphp

                                    @if ($office)
                                        @if ($office->census_no)    
                                            ({{ $office->census_no ?? '' }})
                                        @endif
                                        {{ $office->name ?? ($office->short_name ?? 'N/A') }}
                                    @else
                                    N/A
                                    @endif
                                </span>

                                <span class="text-xs text-gray-500 leading-4">
                                    {{ $employee->currentAppointment?->workplace?->address ?? 'N/A' }}
                                </span>
                            </div>
                        </td>

                        <!-- Contact -->
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                            <div class="flex flex-col">
                                <span class="font-medium">{{ $employee->phone }}</span>
                                <span class="text-xs text-gray-500">{{ $employee->email }}</span>
                            </div>
                        </td>

                        <!-- Status -->
                        <td class="px-6 py-4 whitespace-nowrap">
                            @if($employee->currentAppointment?->appointment?->is_confirmed)
                            <span
                                class="px-2 py-0.5 rounded-full bg-green-100 text-green-700 text-xs font-semibold inline-flex items-center">
                                Confirmed
                            </span>
                            @else
                            <span
                                class="px-2 py-0.5 rounded-full bg-yellow-100 text-yellow-700 text-xs font-semibold inline-flex items-center">
                                Not Confirmed
                            </span>
                            @endif
                        </td>

                        <!-- Actions -->
                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <div class="flex justify-end gap-2">

                                @can('mso.profile.general.view')
                                <a href="{{ route('mso.profile.index', $employee->id) }}">
                                    <flux:button size="sm" icon="eye" variant="ghost">View</flux:button>
                                </a>
                                @endcan

                                @can('mso.profile.id.view')
                                <a href="">
                                    <flux:button size="sm" icon="identification">ID</flux:button>
                                </a>
                                @endcan

                                @can('mso.profile.pdf.view')
                                <a href="">
                                    <flux:button size="sm" icon="document">PDF</flux:button>
                                </a>
                                @endcan

                            </div>
                        </td>
                    </tr>

                    @empty
                    <tr>
                        <td colspan="9" class="text-center py-8">
                            <span class="text-gray-400 text-sm">No employees found</span>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="mt-4">
            {{ $employees->links() }}
        </div>

    </div>
</div>