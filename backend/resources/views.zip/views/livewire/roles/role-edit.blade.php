<div>
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Edit Role') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Form for edit role') }}
        </flux:subheading>
        <flux:separator variant="subtle" />

        <form wire:submit.prevent="updateRole" class="mt-6 w-full space-y-6">

            
            <flux:field class=" max-w-xl">
                <flux:input label="Role Name" wire:model.defer="role_name" placeholder="Enter role name" />
            </flux:field>
            <flux:separator variant="subtle" />
            <flux:checkbox.group wire:model="selectedPermissions" label="Permissions">
                <div class="grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-2">
                    @php
                        $previousPrefix = null;
                    @endphp

                    @foreach ($allPermissions->sortBy('name') as $item)
                        @php
                            $currentPrefix = explode('.', $item->name)[0]; // first prefix only
                        @endphp

                        @if ($previousPrefix !== $currentPrefix)
                            <div class="col-span-full mt-4 mb-1 text-[10px] uppercase tracking-wide text-gray-500">
                                {{ $currentPrefix }}
                            </div>
                        @endif

                        <flux:checkbox
                            label="{{ $item->name }}"
                            value="{{ $item->name }}"
                        />

                        @php
                            $previousPrefix = $currentPrefix;
                        @endphp
                    @endforeach
                </div>
            </flux:checkbox.group>


            <flux:separator variant="subtle" />
            <div class="flex justify-start">
                <flux:button type="submit" variant="primary">
                    Save
                </flux:button>
            </div>
        </form>

        @if (session()->has('success'))
            <div class="mt-4 text-success">
                {{ session('success') }}
            </div>
        @endif

    </div>
</div>

