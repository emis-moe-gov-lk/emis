<div>
    <div class="bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 overflow-hidden">
        <!-- Header with School Info -->
        <div class="p-6 border-b border-slate-200 dark:border-slate-700">
            <div class="flex flex-col md:flex-row md:items-start gap-6">
                <!-- School Logo and Basic Info -->
                <div class="flex-shrink-0">
                    <div class="flex flex-col items-center md:items-start gap-4">
                        <!-- Logo -->
                        <div class="relative">
                            <div class="h-24 w-24 rounded-full border-4 border-white dark:border-slate-700 shadow-lg overflow-hidden bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-slate-900 dark:to-slate-800">
                                <img
                                    src="{{ asset('storage/images/institution/'. $institution->logo) }}"
                                    alt="{{ $institution->name }}"
                                    class="w-full h-full object-cover" />
                            </div>
                            <!-- Status Badge -->
                            <div class="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
                                <span class="px-3 py-1 text-xs font-semibold rounded-full shadow-md
                                {{ $institution->active_status 
                                    ? 'bg-green-500 text-white border-2 border-white dark:border-slate-800' 
                                    : 'bg-red-500 text-white border-2 border-white dark:border-slate-800' }}">
                                    {{ $institution->active_status ? 'ACTIVE' : 'INACTIVE' }}
                                </span>
                            </div>
                        </div>

                        <!-- Quick Stats -->
                        <div class="grid grid-cols-3 gap-3 text-center">
                            <div class="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-2">
                                <div class="text-2xl font-bold text-blue-700 dark:text-blue-300">15622</div>
                                <div class="text-xs text-blue-600 dark:text-blue-400">Students</div>
                            </div>
                            <div class="bg-green-50 dark:bg-green-900/20 rounded-lg p-2">
                                <div class="text-2xl font-bold text-green-700 dark:text-green-300">18</div>
                                <div class="text-xs text-green-600 dark:text-green-400">Teachers</div>
                            </div>
                            <div class="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-2">
                                <div class="text-2xl font-bold text-purple-700 dark:text-purple-300">12</div>
                                <div class="text-xs text-purple-600 dark:text-purple-400">Classes</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- School Details -->
                <div class="flex-1">
                    <!-- School Name and Census -->
                    <div class="mb-4">
                        <div class="flex items-center gap-3 mb-2">
                            <h1 class="text-2xl font-bold text-slate-900 dark:text-white">
                                {{ $institution->name }}
                            </h1>
                            <span class="px-3 py-1 bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 text-sm font-mono rounded-md">
                                #{{ str_pad($institution->census_no, 5, '0', STR_PAD_LEFT) }}
                            </span>
                        </div>

                        <!-- School Type and Grades -->
                        <div class="flex flex-wrap gap-2 mb-3">
                            <span class="px-3 py-1 bg-indigo-100 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-300 text-sm font-medium rounded-full">
                                Primary School
                            </span>
                            <span class="px-3 py-1 bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300 text-sm font-medium rounded-full">
                                Grade 1-5
                            </span>
                            <span class="px-3 py-1 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 text-sm font-medium rounded-full">
                                Co-educational
                            </span>
                        </div>
                    </div>

                    <!-- Contact Information -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                        <div class="space-y-3">
                            <div class="flex items-center gap-3">
                                <div class="p-2 bg-slate-100 dark:bg-slate-700 rounded-lg">
                                    <svg class="w-5 h-5 text-slate-600 dark:text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                                    </svg>
                                </div>
                                <div>
                                    <div class="text-sm text-slate-500 dark:text-slate-400">Phone</div>
                                    <div class="font-medium text-slate-900 dark:text-white">{{ $institution->phone ?? 'Not available' }}</div>
                                </div>
                            </div>

                            <div class="flex items-center gap-3">
                                <div class="p-2 bg-slate-100 dark:bg-slate-700 rounded-lg">
                                    <svg class="w-5 h-5 text-slate-600 dark:text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89-3.46a2 2 0 012.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                                    </svg>
                                </div>
                                <div>
                                    <div class="text-sm text-slate-500 dark:text-slate-400">Email</div>
                                    <div class="font-medium text-slate-900 dark:text-white">{{ $institution->email ?? 'Not available' }}</div>
                                </div>
                            </div>
                        </div>

                        <div class="space-y-3">
                            <div class="flex items-center gap-3">
                                <div class="p-2 bg-slate-100 dark:bg-slate-700 rounded-lg">
                                    <svg class="w-5 h-5 text-slate-600 dark:text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                                    </svg>
                                </div>
                                <div>
                                    <div class="text-sm text-slate-500 dark:text-slate-400">Principal</div>
                                    <div class="font-medium text-slate-900 dark:text-white">Mr. John Smith</div>
                                </div>
                            </div>

                            <div class="flex items-center gap-3">
                                <div class="p-2 bg-slate-100 dark:bg-slate-700 rounded-lg">
                                    <svg class="w-5 h-5 text-slate-600 dark:text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                </div>
                                <div>
                                    <div class="text-sm text-slate-500 dark:text-slate-400">Established</div>
                                    <div class="font-medium text-slate-900 dark:text-white">1995</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Education Office Info -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="bg-gradient-to-r from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20 rounded-lg p-4">
                            <div class="flex items-center justify-between">
                                <div>
                                    <div class="text-sm text-blue-600 dark:text-blue-400 font-medium mb-1">Zonal Education Office</div>
                                    <div class="text-lg font-bold text-blue-800 dark:text-blue-300">
                                        {{ $institution->zonalEducationOffice->name ?? 'N/A' }}
                                    </div>
                                    <div class="text-sm text-blue-700 dark:text-blue-400">
                                        {{ $institution->zonalEducationOffice->short_name ?? '' }}
                                    </div>
                                </div>
                                <div class="text-blue-500 dark:text-blue-400">
                                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                                    </svg>
                                </div>
                            </div>
                        </div>

                        <div class="bg-gradient-to-r from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20 rounded-lg p-4">
                            <div class="flex items-center justify-between">
                                <div>
                                    <div class="text-sm text-purple-600 dark:text-purple-400 font-medium mb-1">Divisional Education Office</div>
                                    <div class="text-lg font-bold text-purple-800 dark:text-purple-300">
                                        {{ $institution->divisionalEducationOffice->name ?? 'N/A' }}
                                    </div>
                                    <div class="text-sm text-purple-700 dark:text-purple-400">
                                        {{ $institution->divisionalEducationOffice->short_name ?? '' }}
                                    </div>
                                </div>
                                <div class="text-purple-500 dark:text-purple-400">
                                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Map and Address Section -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 p-6">
            <!-- Address Details -->
            <div class="lg:col-span-1">
                <div class="bg-slate-50 dark:bg-slate-900/50 rounded-xl p-5 h-full">
                    <h3 class="text-lg font-semibold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                        <svg class="w-5 h-5 text-slate-600 dark:text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                        Location Details
                    </h3>

                    <div class="space-y-4">
                        <div>
                            <div class="text-sm font-medium text-slate-600 dark:text-slate-400 mb-1">Full Address</div>
                            <div class="text-slate-900 dark:text-white leading-relaxed">
                                {{ $institution->address }}
                            </div>
                        </div>

                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <div class="text-sm font-medium text-slate-600 dark:text-slate-400 mb-1">Province</div>
                                <div class="text-slate-900 dark:text-white">Western Province</div>
                            </div>
                            <div>
                                <div class="text-sm font-medium text-slate-600 dark:text-slate-400 mb-1">District</div>
                                <div class="text-slate-900 dark:text-white">Colombo</div>
                            </div>
                            <div>
                                <div class="text-sm font-medium text-slate-600 dark:text-slate-400 mb-1">Divisional Secretariat</div>
                                <div class="text-slate-900 dark:text-white">Colombo DS Division</div>
                            </div>
                            <div>
                                <div class="text-sm font-medium text-slate-600 dark:text-slate-400 mb-1">Grama Niladhari Division</div>
                                <div class="text-slate-900 dark:text-white">Colombo GND</div>
                            </div>
                        </div>

                        <!-- Map Actions -->
                        <div class="pt-4 border-t border-slate-200 dark:border-slate-700">
                            <div class="flex flex-wrap gap-3">
                                <button class="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />
                                    </svg>
                                    Get Directions
                                </button>
                                <button class="flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg transition-colors">
                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                                    </svg>
                                    Share Location
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Map Container -->
            <div class="lg:col-span-2">
                <div class="bg-slate-100 dark:bg-slate-900 rounded-xl overflow-hidden h-full border border-slate-300 dark:border-slate-700">
                    <!-- Map Header -->
                    <div class="bg-white dark:bg-slate-800 px-4 py-3 border-b border-slate-300 dark:border-slate-700">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center gap-2">
                                <svg class="w-5 h-5 text-red-500" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd" />
                                </svg>
                                <span class="font-medium text-slate-900 dark:text-white">School Location on Map</span>
                            </div>
                            <div class="flex items-center gap-2">
                                <button class="p-2 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg">
                                    <svg class="w-4 h-4 text-slate-600 dark:text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                    </svg>
                                </button>
                                <button class="p-2 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg">
                                    <svg class="w-4 h-4 text-slate-600 dark:text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5v-4m0 4h-4m4 0l-5-5" />
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Interactive Map Placeholder (Replace with actual map integration) -->
                    <div class="relative h-96 bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-slate-900 dark:to-slate-800 overflow-hidden">
                        <!-- Map Grid Background -->
                        <div class="absolute inset-0 opacity-20">
                            <div class="absolute inset-0" style="background-image: linear-gradient(to right, #64748b 1px, transparent 1px), linear-gradient(to bottom, #64748b 1px, transparent 1px); background-size: 40px 40px;"></div>
                        </div>

                        <!-- Map Center (School Location) -->
                        <div class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
                            <!-- School Marker -->
                            <div class="relative">
                                <!-- Pulse Animation -->
                                <div class="absolute inset-0 animate-ping">
                                    <div class="h-24 w-24 rounded-full bg-red-400 opacity-20"></div>
                                </div>

                                <!-- Marker -->
                                <div class="relative flex flex-col items-center">
                                    <div class="bg-white dark:bg-slate-800 p-2 rounded-full shadow-xl border-2 border-red-500">
                                        <div class="h-12 w-12 rounded-full bg-gradient-to-br from-red-500 to-red-600 flex items-center justify-center shadow-lg">
                                            <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                                            </svg>
                                        </div>
                                    </div>

                                    <!-- Label -->
                                    <div class="mt-2 bg-white dark:bg-slate-800 px-3 py-2 rounded-lg shadow-lg border border-slate-200 dark:border-slate-700">
                                        <div class="text-sm font-semibold text-slate-900 dark:text-white">{{ $institution->name }}</div>
                                        <div class="text-xs text-slate-500 dark:text-slate-400">{{ $institution->address }}</div>
                                    </div>
                                </div>
                            </div>

                            <!-- Nearby Landmarks -->
                            <div class="absolute top-20 left-20">
                                <div class="flex items-center gap-2 bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm px-3 py-2 rounded-lg shadow-sm border border-slate-200 dark:border-slate-700">
                                    <div class="h-8 w-8 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center">
                                        <svg class="w-4 h-4 text-blue-600 dark:text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z" />
                                        </svg>
                                    </div>
                                    <div>
                                        <div class="text-xs font-medium text-slate-900 dark:text-white">Hospital</div>
                                        <div class="text-xs text-slate-500 dark:text-slate-400">2km</div>
                                    </div>
                                </div>
                            </div>

                            <div class="absolute bottom-20 right-20">
                                <div class="flex items-center gap-2 bg-white/90 dark:bg-slate-800/90 backdrop-blur-sm px-3 py-2 rounded-lg shadow-sm border border-slate-200 dark:border-slate-700">
                                    <div class="h-8 w-8 rounded-full bg-green-100 dark:bg-green-900/50 flex items-center justify-center">
                                        <svg class="w-4 h-4 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                                        </svg>
                                    </div>
                                    <div>
                                        <div class="text-xs font-medium text-slate-900 dark:text-white">Residential Area</div>
                                        <div class="text-xs text-slate-500 dark:text-slate-400">1.5km</div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Map Controls -->
                        <div class="absolute bottom-4 right-4 flex flex-col gap-2">
                            <button class="bg-white dark:bg-slate-800 p-2 rounded-lg shadow-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
                                <svg class="w-5 h-5 text-slate-700 dark:text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 11l7-7 7 7M5 19l7-7 7 7" />
                                </svg>
                            </button>
                            <button class="bg-white dark:bg-slate-800 p-2 rounded-lg shadow-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors">
                                <svg class="w-5 h-5 text-slate-700 dark:text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                                </svg>
                            </button>
                            <button class="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-lg shadow-lg border border-blue-700 transition-colors">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0zM15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                </svg>
                            </button>
                        </div>

                        <!-- Map Attribution -->
                        <div class="absolute bottom-2 left-2">
                            <div class="text-xs text-slate-500 dark:text-slate-400 bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm px-2 py-1 rounded">
                                © OpenStreetMap contributors
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Actions -->
        <div class="px-6 py-4 bg-slate-50 dark:bg-slate-900/30 border-t border-slate-200 dark:border-slate-700">
            <div class="flex flex-wrap items-center justify-between gap-4">
                <div class="text-sm text-slate-500 dark:text-slate-400">
                    Last updated: {{ $institution->updated_at->format('M d, Y') }}
                </div>
                <div class="flex flex-wrap gap-3">
                    <button class="px-4 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg transition-colors flex items-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                        Generate Report
                    </button>
                    <button class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors flex items-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                        </svg>
                        Edit Profile
                    </button>
                    <button class="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition-colors flex items-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        Schedule Visit
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>