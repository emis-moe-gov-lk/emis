<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Main System Tables Overview') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Main System Tables and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-main-tables.layout>
        <div>
            <div class="relative mb-6 w-full">
                <div class="relative mb-6 w-full">
                    <flux:heading size="xl" level="1">{{ __('Police Stations') }}</flux:heading>
                    <flux:subheading size="lg" class="mb-6">
                        {{ __('Manage Police Stations and related information') }}
                    </flux:subheading>
                    <flux:separator variant="subtle" />
                </div>

                <div class="my-4 gap-2 justify-end flex">

                    <flux:modal.trigger name="add-new-police-station">
                        <flux:button icon="plus" color="primary"
                            class="px-4 py-2 font-medium shadow-sm transition-all hover:shadow-md">Add new Police Station</flux:button>
                    </flux:modal.trigger>

                </div>

                @if (session()->has('message'))
                    <div class="p-3 mb-5 rounded-md bg-green-100 text-green-800 text-sm font-semibold">
                        {{ session('message') }}
                    </div>
                @endif

                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700 overflow-x-auto">
                    <thead class="bg-slate-50 dark:bg-slate-800">
                        <tr>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Police Station Name & ID
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Police Station Address
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Police Station Phone & Email
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Status
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-right text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-900 divide-y divide-slate-200 dark:divide-slate-700">
                        @forelse ($police_stations as $key => $data)
                            <tr class="hover:bg-slate-100 dark:hover:bg-slate-800 transition">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="flex-shrink-0 h-10 w-10 text-sm font-medium">
                                            {{ $police_stations->firstItem() + $key }}
                                        </div>
                                        <div class="ml-4">
                                            <div class="text-sm font-medium text-slate-900 dark:text-slate-100">
                                                <flux:link href="" variant="ghost">
                                                    {{ $data->police_station_name }}</flux:link>
                                            </div>
                                            <div class="text-sm text-slate-500 dark:text-slate-400">
                                                Police Station Id: {{ $data->police_station_id }}
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-slate-900 dark:text-slate-100">{{ $data->address }} <br> {{ $data->postal_code }}</div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="ml-4">
                                            <div class="text-sm font-medium text-slate-900 dark:text-slate-100">
                                                {{ $data->phone }}
                                            </div>
                                            <div class="text-sm text-slate-500 dark:text-slate-400">
                                                {{ $data->email }}
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span
                                        class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                                {{ $data->active_status ? 'bg-green-100 text-green-800 dark:bg-green-700 dark:text-green-100' : 'bg-red-100 text-red-800 dark:bg-red-700 dark:text-red-100' }}">
                                        {{ $data->active_status ? 'Active' : 'Inactive' }}
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium justify-end flex gap-1">
                                    <flux:modal.trigger wire:click="editPoliceStation({{ $data->id }})">
                                        <flux:button size="sm" icon="pencil-square"></flux:button>
                                    </flux:modal.trigger>
                                    <flux:button wire:click="toggleStatus({{ $data->id }})"
                                        wire:confirm="Are you sure you want to {{ $data->active_status == '1' ? 'deactivate' : 'activate' }} this Police Station?"
                                        size="sm" icon="{{ $data->active_status == '1' ? 'no-symbol' : 'check' }}"
                                        variant="{{ $data->active_status == '1' ? 'danger' : 'primary' }}">
                                    </flux:button>
                                </td>
                            </tr>
                        @empty
                            <tr colspan="4">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-slate-900 dark:text-slate-100">No Police Station Found!
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>



                <div class="mt-4 mx-10">
                    {{ $police_stations->links() }}
                </div>
            </div>
        </div>

        <flux:modal wire:model="showModelNewPoliceStation" name="add-new-police-station" class="md:w-96">
            <div class="space-y-6">
                <div>
                    <flux:heading size="lg">Add new Police Station</flux:heading>
                    <flux:text class="mt-2">Add new police station to your system.
                    </flux:text>
                </div>
                <form wire:submit.prevent="addNewPoliceStation">
                    @csrf
                    <div class="mt-6 max-w-xl space-y-4">

                        <flux:field>
                            <flux:input label="Police Station ID" wire:model.live="police_station_id"
                                placeholder="Enter Service ID" mask="PSID999"/>
                        </flux:field>

                        <flux:field>
                            <flux:input label="Police Station Name" wire:model.live="police_station_name" placeholder="Enter police station name" />
                        </flux:field>

                        <flux:field>
                            <flux:textarea label="Police Station Address" wire:model.live="address" placeholder="Enter police station address" />
                        </flux:field>

                        <flux:field>
                            <flux:input label="Police Station Postal Code" wire:model.live="postal_code" placeholder="Enter police station postal code" />
                        </flux:field>

                        <flux:field>
                            <flux:input label="Police Station Phone" wire:model.live="phone" placeholder="Enter police station phone" />
                        </flux:field>

                        <flux:field>
                            <flux:input label="Police Station Email" wire:model.live="email" placeholder="Enter police station email" />
                        </flux:field>
                    </div>

                    <div class="flex mt-4">
                        <flux:spacer />
                        <flux:button type="submit" variant="primary">Add Police Station</flux:button>
                    </div>
                </form>
            </div>
        </flux:modal>

        <flux:modal wire:model="showModelEditPoliceStation" name="edit-police-station" class="md:w-96">
            <div class="space-y-6">
                <div>
                    <flux:heading size="lg">Edit Police Station</flux:heading>
                    <flux:text class="mt-2">Change police station information on your system.
                    </flux:text>
                </div>
                <form wire:submit.prevent="updatePoliceStation">
                    @csrf
                    <div class="mt-6 max-w-xl space-y-4">

                        <flux:field>
                            <flux:input disabled label="Police Station ID" wire:model.live="update_police_station_id"
                                placeholder="Enter Service ID" mask="PSID999"/>
                        </flux:field>

                        <flux:field>
                            <flux:input label="Police Station Name" wire:model.live="update_police_station_name" placeholder="Enter service name" />
                        </flux:field>

                        <flux:field>
                            <flux:textarea label="Police Station Address" wire:model.live="update_address" placeholder="Enter service Description" />
                        </flux:field>

                        <flux:field>
                            <flux:input label="Police Station Postal Code" wire:model.live="update_postal_code" placeholder="Enter service Description" />
                        </flux:field>

                        <flux:field>
                            <flux:input label="Police Station Phone" wire:model.live="update_phone" placeholder="Enter service Description" />
                        </flux:field>

                        <flux:field>
                            <flux:input label="Police Station Email" wire:model.live="update_email" placeholder="Enter service Description" />
                        </flux:field>
                    </div>

                    <div class="flex mt-4">
                        <flux:spacer />
                        <flux:button type="submit" name="edit" variant="primary">Save changes</flux:button>
                    </div>
                </form>
            </div>
        </flux:modal>
    </x-main-tables.layout>
</section>
