<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Main System Tables Overview') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Main System Tables and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-main-tables.layout>
        <div>
            <div class="relative mb-6 w-full">
                <div class="relative mb-6 w-full">
                    <flux:heading size="xl" level="1">{{ __('Change Logs') }}</flux:heading>
                    <flux:subheading size="lg" class="mb-6">
                        {{ __('Manage Change Logs and related information') }}
                    </flux:subheading>
                    <flux:separator variant="subtle" />
                </div>

                <div class="my-4 gap-2 justify-end flex">

                    <flux:modal.trigger name="add-new-change-log">
                        <flux:button icon="plus" color="primary"
                            class="px-4 py-2 font-medium shadow-sm transition-all hover:shadow-md">Add new Change</flux:button>
                    </flux:modal.trigger>

                </div>

                @if (session()->has('message'))
                    <div class="p-3 mb-5 rounded-md bg-green-100 text-green-800 text-sm font-semibold">
                        {{ session('message') }}
                    </div>
                @endif

                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700 overflow-x-auto">
                    <thead class="bg-slate-50 dark:bg-slate-800">
                        <tr>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                #
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Version ID
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Type
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Title & Description
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-right text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-900 divide-y divide-slate-200 dark:divide-slate-700">
                        @forelse ($changelogs as $key => $data)
                            <tr class="hover:bg-slate-100 dark:hover:bg-slate-800 transition">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="flex-shrink-0 h-10 w-10 text-sm font-medium">
                                            {{ $changelogs->firstItem() + $key }}
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="flex-shrink-0 h-10 w-10 text-sm font-medium">
                                            {{ $data->version_id }}
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="flex-shrink-0 h-10 w-10 text-sm font-medium">
                                            {{ $data->type }}
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="ml-4">
                                            <div class="text-sm font-medium text-slate-900 dark:text-slate-100">
                                                    {{ $data->title }}
                                            </div>
                                            <div class="text-sm text-slate-500 dark:text-slate-400">
                                                {{ $data->description }}
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium justify-end flex gap-1">
                                    <flux:modal.trigger wire:click="editChangeLog({{ $data->id }})">
                                        <flux:button size="sm" icon="pencil-square"></flux:button>
                                    </flux:modal.trigger>
                                    <flux:button wire:click="deleteChangeLog({{ $data->id }})"
                                        wire:confirm="Are you sure you want to delete this Change Log?"
                                        size="sm" icon="trash" color="danger">
                                    </flux:button>
                                </td>
                            </tr>
                        @empty
                            <tr colspan="4">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-slate-900 dark:text-slate-100">No Change Log Found!
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>



                <div class="mt-4 mx-10">
                    {{ $changelogs->links() }}
                </div>
            </div>
        </div>

        <flux:modal wire:model="showModelNewChangeLog" name="add-new-change-log" class="md:w-96">
            <div class="space-y-6">
                <div>
                    <flux:heading size="lg">Add new Change Log</flux:heading>
                    <flux:text class="mt-2">Add new Change Log to your system.
                    </flux:text>
                </div>
                @if (session()->has('error'))
                    <div class="p-3 mb-5 rounded-md bg-red-100 text-red-800 text-sm font-semibold">
                        {{ session('error') }}
                    </div>
                @endif
                <form wire:submit.prevent="addNewChangeLog">
                    @csrf
                    <div class="mt-6 max-w-xl space-y-4">

                        <flux:field>
                            <flux:select label="Version" id="versionId" wire:model.live="versionId">
                                <option value="">{{ __ ('Select Version') }}</option>
                                @foreach ($versionOption as $version)
                                    <option value="{{ $version->version_id }}">{{ $version->version }}</option>
                                @endforeach
                            </flux:select>
                        </flux:field>

                        <flux:field>
                            <flux:select label="Type" id="type" wire:model.live="type">
                                <option value="">{{ __ ('Select Type') }}</option>
                                <option value="added">{{ 'Added' }}</option>
                                <option value="modified">{{ 'Modified' }}</option>
                                <option value="fixed">{{ 'Fixed' }}</option>
                                <option value="removed">{{ 'Removed' }}</option>
                                <option value="security">{{ 'Security' }}</option>
                            </flux:select>
                        </flux:field>

                        <flux:field>
                            <flux:input label="Title" wire:model.live="title" placeholder="Enter Title" />
                        </flux:field>

                        <flux:field>
                            <flux:textarea label="Description" wire:model.live="description" placeholder="Enter Description" rows="4" />
                        </flux:field>

                    </div>


                    <div class="flex mt-4">
                        <flux:spacer />
                        <flux:button type="submit" variant="primary">Add Change</flux:button>
                    </div>
                </form>
            </div>
        </flux:modal>

        <flux:modal wire:model="showModelEditChangeLog" name="edit-change-log" class="md:w-96">
            <div class="space-y-6">
                <div>
                    <flux:heading size="lg">Edit Change Log</flux:heading>
                    <flux:text class="mt-2">Change Change Log information on your system.
                    </flux:text>
                </div>
                @if (session()->has('error'))
                    <div class="p-3 mb-5 rounded-md bg-red-100 text-red-800 text-sm font-semibold">
                        {{ session('error') }}
                    </div>
                @endif
                <form wire:submit.prevent="updateChangeLog">
                    @csrf
                    <div class="mt-6 max-w-xl space-y-4">

                        <flux:field>
                            <flux:select label="Version" id="updateVersionId" wire:model.live="updateVersionId">
                                <option value="">{{ __ ('Select Version') }}</option>
                                @foreach ($versionOption as $version)
                                    <option value="{{ $version->version_id }}">{{ $version->version }}</option>
                                @endforeach
                            </flux:select>
                        </flux:field>

                        <flux:field>
                            <flux:select label="Type" id="updateType" wire:model.live="updateType">
                                <option value="">{{ __ ('Select Type') }}</option>
                                <option value="added">{{ 'Added' }}</option>
                                <option value="modified">{{ 'Modified' }}</option>
                                <option value="fixed">{{ 'Fixed' }}</option>
                                <option value="removed">{{ 'Removed' }}</option>
                                <option value="security">{{ 'Security' }}</option>
                            </flux:select>
                        </flux:field>

                        <flux:field>
                            <flux:input label="Title" wire:model.live="updateTitle" placeholder="Enter Title" />
                        </flux:field>

                        <flux:field>
                            <flux:textarea label="Description" wire:model.live="updateDescription" placeholder="Enter Description" rows="4" />
                        </flux:field>

                    </div>

                    <div class="flex mt-4">
                        <flux:spacer />
                        <flux:button type="submit" name="edit" variant="primary">Save changes</flux:button>
                    </div>
                </form>
            </div>
        </flux:modal>

    </x-main-tables.layout>
</section>
