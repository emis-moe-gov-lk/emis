<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Main System Tables Overview') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Main System Tables and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-main-tables.layout>
        <div>
            <div class="relative mb-6 w-full">
                <div class="relative mb-6 w-full">
                    <flux:heading size="xl" level="1">{{ __('Institutional Facilities') }}</flux:heading>
                    <flux:subheading size="lg" class="mb-6">
                        {{ __('Manage Institutional Facilities and related information') }}
                    </flux:subheading>
                    <flux:separator variant="subtle" />
                </div>

                <div class="my-4 gap-2 justify-end flex">

                    <flux:modal.trigger name="add-new-institutional-facility">
                        <flux:button icon="plus" color="primary"
                            class="px-4 py-2 font-medium shadow-sm transition-all hover:shadow-md">Add new Institutional Facility</flux:button>
                    </flux:modal.trigger>

                </div>

                @if (session()->has('message'))
                    <div class="p-3 mb-5 rounded-md bg-green-100 text-green-800 text-sm font-semibold">
                        {{ session('message') }}
                    </div>
                @endif

                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700 overflow-x-auto">
                    <thead class="bg-slate-50 dark:bg-slate-800">
                        <tr>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Facility Name & ID
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Facility Discription
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Status
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-right text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-900 divide-y divide-slate-200 dark:divide-slate-700">
                        @forelse ($institutional_facilities as $key => $data)
                            <tr class="hover:bg-slate-100 dark:hover:bg-slate-800 transition">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="flex-shrink-0 h-10 w-10 text-sm font-medium">
                                            {{ $institutional_facilities->firstItem() + $key }}
                                        </div>
                                        <div class="ml-4">
                                            <div class="text-sm font-medium text-slate-900 dark:text-slate-100">
                                                <flux:link href="" variant="ghost">
                                                    {{ $data->name }}</flux:link>
                                            </div>
                                            <div class="text-sm text-slate-500 dark:text-slate-400">
                                                Facility Id: {{ $data->facilities_id }}
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-slate-900 dark:text-slate-100">{{ $data->description }}</div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span
                                        class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                                {{ $data->active_status ? 'bg-green-100 text-green-800 dark:bg-green-700 dark:text-green-100' : 'bg-red-100 text-red-800 dark:bg-red-700 dark:text-red-100' }}">
                                        {{ $data->active_status ? 'Active' : 'Inactive' }}
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium justify-end flex gap-1">
                                    <flux:modal.trigger wire:click="editInstitutionalFacility({{ $data->id }})">
                                        <flux:button size="sm" icon="pencil-square"></flux:button>
                                    </flux:modal.trigger>
                                    <flux:button wire:click="toggleStatus({{ $data->id }})"
                                        wire:confirm="Are you sure you want to {{ $data->active_status == '1' ? 'deactivate' : 'activate' }} this facility?"
                                        size="sm" icon="{{ $data->active_status == '1' ? 'no-symbol' : 'check' }}"
                                        variant="{{ $data->active_status == '1' ? 'danger' : 'primary' }}">
                                    </flux:button>
                                </td>
                            </tr>
                        @empty
                            <tr colspan="4">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-slate-900 dark:text-slate-100">No institution types Found!
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>



                <div class="mt-4 mx-10">
                    {{ $institutional_facilities->links() }}
                </div>
            </div>
        </div>

        <flux:modal wire:model="showModelNewInstitutionalFacility" name="add-new-institutional-facility" class="md:w-96">
            <div class="space-y-6">
                <div>
                    <flux:heading size="lg">Add new Institutional Facility</flux:heading>
                    <flux:text class="mt-2">Add new institutional facility to your system.
                    </flux:text>
                </div>
                <form wire:submit.prevent="addNewInstitutionalFacility">
                    @csrf
                    <div class="mt-6 max-w-xl space-y-4">

                        <flux:field>
                            <flux:input label="Facility ID" wire:model.live="facilities_id"
                                placeholder="Enter Facility ID" mask="FAC999"/>
                        </flux:field>

                        <flux:field>
                            <flux:input label="Facility Name" wire:model.live="facilities_name" placeholder="Enter facility name" />
                        </flux:field>

                        <flux:field>
                            <flux:textarea label="Facility Description" wire:model.live="description" placeholder="Enter facility description" />
                        </flux:field>

                    </div>

                    <div class="flex mt-4">
                        <flux:spacer />
                        <flux:button type="submit" variant="primary">Add Facility</flux:button>
                    </div>
                </form>
            </div>
        </flux:modal>

        <flux:modal wire:model="showModelEditInstitutionalFacility" name="edit-institutional-facility" class="md:w-96">
            <div class="space-y-6">
                <div>
                    <flux:heading size="lg">Edit Institutional Facility</flux:heading>
                    <flux:text class="mt-2">Change institution facility information on your system.
                    </flux:text>
                </div>
                <form wire:submit.prevent="updateInstitutionalFacility">
                    @csrf
                    <div class="mt-6 max-w-xl space-y-4">

                        <flux:field>
                            <flux:input disabled label="Facility ID" wire:model.live="update_facilities_id"
                                placeholder="Enter Facility ID" mask="FAC999"/>
                        </flux:field>

                        <flux:field>
                            <flux:input label="Facility Name" wire:model.live="update_facilities_name" placeholder="Enter facility name" />
                        </flux:field>

                        <flux:field>
                            <flux:textarea label="Facility Description" wire:model.live="update_description" placeholder="Enter facility description" />
                        </flux:field>

                    </div>

                    <div class="flex mt-4">
                        <flux:spacer />
                        <flux:button type="submit" name="edit" variant="primary">Save changes</flux:button>
                    </div>
                </form>
            </div>
        </flux:modal>
    </x-main-tables.layout>
</section>
