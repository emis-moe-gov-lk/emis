<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Main System Tables Overview') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Main System Tables and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-main-tables.layout>
        <div>
            <div class="relative mb-6 w-full">
                <div class="relative mb-6 w-full">
                    <flux:heading size="xl" level="1">{{ __('Versions') }}</flux:heading>
                    <flux:subheading size="lg" class="mb-6">
                        {{ __('Manage Versions and related information') }}
                    </flux:subheading>
                    <flux:separator variant="subtle" />
                </div>

                <div class="my-4 gap-2 justify-end flex">

                    <flux:modal.trigger name="add-new-version">
                        <flux:button icon="plus" color="primary"
                            class="px-4 py-2 font-medium shadow-sm transition-all hover:shadow-md">Add new Version</flux:button>
                    </flux:modal.trigger>

                </div>

                @if (session()->has('message'))
                    <div class="p-3 mb-5 rounded-md bg-green-100 text-green-800 text-sm font-semibold">
                        {{ session('message') }}
                    </div>
                @endif

                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700 overflow-x-auto">
                    <thead class="bg-slate-50 dark:bg-slate-800">
                        <tr>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Version ID
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Version
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Release Date
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Title & Description
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Is Latest
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-right text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-900 divide-y divide-slate-200 dark:divide-slate-700">
                        @forelse ($versions as $key => $data)
                            <tr class="hover:bg-slate-100 dark:hover:bg-slate-800 transition">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="flex-shrink-0 h-10 w-10 text-sm font-medium">
                                            {{ $versions->firstItem() + $key }}
                                        </div>
                                        <div class="ml-4">
                                            <div class="flex-shrink-0 h-10 w-10 text-sm font-medium">
                                                <flux:link href="" variant="ghost">
                                                    {{ $data->version_id }}
                                                </flux:link>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="flex-shrink-0 h-10 w-10 text-sm font-medium">
                                            {{ $data->version }}
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="flex-shrink-0 h-10 w-10 text-sm font-medium">
                                            {{ $data->release_date->format('Y-m-d') }}
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="ml-4">
                                            <div class="text-sm font-medium text-slate-900 dark:text-slate-100">
                                                    {{ $data->title }}
                                            </div>
                                            <div class="text-sm text-slate-500 dark:text-slate-400">
                                                {{ $data->description }}
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span
                                        class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                                {{ $data->is_latest ? 'bg-green-100 text-green-800 dark:bg-green-700 dark:text-green-100' : 'bg-red-100 text-red-800 dark:bg-red-700 dark:text-red-100' }}">
                                        {{ $data->is_latest ? 'Yes' : 'No' }}
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium justify-end flex gap-1">
                                    <flux:modal.trigger wire:click="editVersion({{ $data->id }})">
                                        <flux:button size="sm" icon="pencil-square"></flux:button>
                                    </flux:modal.trigger>
                                    <flux:button wire:click="toggleStatus({{ $data->id }})"
                                        wire:confirm="Are you sure you want to {{ $data->is_latest == '1' ? 'deactivate' : 'activate' }} this Version?"
                                        size="sm" icon="{{ $data->is_latest == '1' ? 'no-symbol' : 'check' }}"
                                        variant="{{ $data->is_latest == '1' ? 'danger' : 'primary' }}">
                                    </flux:button>
                                </td>
                            </tr>
                        @empty
                            <tr colspan="4">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-slate-900 dark:text-slate-100">No Version Found!
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>



                <div class="mt-4 mx-10">
                    {{ $versions->links() }}
                </div>
            </div>
        </div>

        <flux:modal wire:model="showModelNewVersion" name="add-new-version" class="md:w-96">
            <div class="space-y-6">
                <div>
                    <flux:heading size="lg">Add new Version</flux:heading>
                    <flux:text class="mt-2">Add new Version to your system.
                    </flux:text>
                </div>
                @if (session()->has('error'))
                    <div class="p-3 mb-5 rounded-md bg-red-100 text-red-800 text-sm font-semibold">
                        {{ session('error') }}
                    </div>
                @endif
                <form wire:submit.prevent="addNewVersion">
                    @csrf
                    <div class="mt-6 max-w-xl space-y-4">

                        <flux:field>
                            <flux:input label="Version ID" wire:model.live="versionId"
                                placeholder="Enter Version ID" mask="VER999"/>
                        </flux:field>

                        <flux:field>
                            <flux:input label="Version" wire:model.live="version" placeholder="Enter Version" />
                        </flux:field>

                        <flux:field>
                            <flux:input label="Release Date" type="date" wire:model.live="releaseDate" placeholder="Enter Release Date" />
                        </flux:field>

                        <flux:field>
                            <flux:input label="Title" wire:model.live="title" placeholder="Enter Title" />
                        </flux:field>

                        <flux:field>
                            <flux:textarea label="Description" wire:model.live="description" placeholder="Enter Description" rows="4" />
                        </flux:field>

                        <flux:field>
                            <flux:checkbox label="Is Latest" wire:model.live="isLatest" />
                        </flux:field>

                    </div>


                    <div class="flex mt-4">
                        <flux:spacer />
                        <flux:button type="submit" variant="primary">Add Version</flux:button>
                    </div>
                </form>
            </div>
        </flux:modal>

        <flux:modal wire:model="showModelEditVersion" name="edit-version" class="md:w-96">
            <div class="space-y-6">
                <div>
                    <flux:heading size="lg">Edit Version</flux:heading>
                    <flux:text class="mt-2">Change Version information on your system.
                    </flux:text>
                </div>
                @if (session()->has('error'))
                    <div class="p-3 mb-5 rounded-md bg-red-100 text-red-800 text-sm font-semibold">
                        {{ session('error') }}
                    </div>
                @endif
                <form wire:submit.prevent="updateVersionList">
                    @csrf
                    <div class="mt-6 max-w-xl space-y-4">

                        <flux:field>
                            <flux:input disabled label="Version ID" wire:model.live="updateVersionId"
                                placeholder="Enter Version ID" mask="VER999"/>
                        </flux:field>

                        <flux:field>
                            <flux:input label="Version" wire:model.live="updateVersion" placeholder="Enter Version" />
                        </flux:field>

                        <flux:field>
                            <flux:input label="Release Date" type="date" wire:model.live="updateReleaseDate" placeholder="Enter Release Date" />
                        </flux:field>

                        <flux:field>
                            <flux:input label="Title" wire:model.live="updateTitle" placeholder="Enter Title" />
                        </flux:field>

                        <flux:field>
                            <flux:textarea label="Description" wire:model.live="updateDescription" placeholder="Enter Description" rows="4" />
                        </flux:field>

                        <flux:field>
                            <flux:checkbox label="Is Latest" wire:model.live="updateIsLatest" />
                        </flux:field>

                    </div>

                    <div class="flex mt-4">
                        <flux:spacer />
                        <flux:button type="submit" name="edit" variant="primary">Save changes</flux:button>
                    </div>
                </form>
            </div>
        </flux:modal>

    </x-main-tables.layout>
</section>
