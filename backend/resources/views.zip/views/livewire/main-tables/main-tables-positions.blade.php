<section class="w-full">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">{{ __('Main System Tables Overview') }}</flux:heading>
        <flux:subheading size="lg" class="mb-6">{{ __('Manage Main System Tables and settings') }}
        </flux:subheading>
        <flux:separator variant="subtle" />
    </div>

    <x-main-tables.layout>
        <div>
            <div class="relative mb-6 w-full">
                <div class="relative mb-6 w-full">
                    <flux:heading size="xl" level="1">{{ __('Positions') }}</flux:heading>
                    <flux:subheading size="lg" class="mb-6">
                        {{ __('Manage Positions and related information') }}
                    </flux:subheading>
                    <flux:separator variant="subtle" />
                </div>

                <div class="my-4 gap-2 justify-end flex">

                    <flux:modal.trigger name="add-new-position">
                        <flux:button icon="plus" color="primary"
                            class="px-4 py-2 font-medium shadow-sm transition-all hover:shadow-md">Add new Position</flux:button>
                    </flux:modal.trigger>

                </div>

                @if (session()->has('message'))
                    <div class="p-3 mb-5 rounded-md bg-green-100 text-green-800 text-sm font-semibold">
                        {{ session('message') }}
                    </div>
                @endif

                <table class="min-w-full divide-y divide-slate-200 dark:divide-slate-700 overflow-x-auto">
                    <thead class="bg-slate-50 dark:bg-slate-800">
                        <tr>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Position Name & ID
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Service Name & ID
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Status
                            </th>
                            <th scope="col"
                                class="px-6 py-3 text-right text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">
                                Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-slate-900 divide-y divide-slate-200 dark:divide-slate-700">
                        @forelse ($positionList as $key => $data)
                            <tr class="hover:bg-slate-100 dark:hover:bg-slate-800 transition">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="shrink-0 h-10 w-10 text-sm font-medium">
                                            {{ $positionList->firstItem() + $key }}
                                        </div>
                                        <div class="ml-4">
                                            <div class="text-sm font-medium text-slate-900 dark:text-slate-100">
                                                    {{ $data->position_name }}
                                            </div>
                                            <div class="text-sm text-slate-500 dark:text-slate-400">
                                                Position Id: {{ $data->position_id }}
                                            </div>
                                            <div class="text-sm text-slate-500 dark:text-slate-400 whitespace-normal break-words">
                                                Description: {{ $data->description }}
                                            </div>
                                        </div>
                                    </div>
                                </td>

                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="ml-4">
                                            <div class="text-sm font-medium text-slate-900 dark:text-slate-100">
                                                    {{ $data->service->service_name }}
                                            </div>
                                            <div class="text-sm text-slate-500 dark:text-slate-400">
                                                Service Id: {{ $data->service_id }}
                                            </div>
                                        </div>
                                    </div>
                                </td>

                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span
                                        class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                                {{ $data->active_status ? 'bg-green-100 text-green-800 dark:bg-green-700 dark:text-green-100' : 'bg-red-100 text-red-800 dark:bg-red-700 dark:text-red-100' }}">
                                        {{ $data->active_status ? 'Active' : 'Inactive' }}
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium justify-end flex gap-1">
                                    <flux:modal.trigger wire:click="editPosition({{ $data->id }})">
                                        <flux:button size="sm" icon="pencil-square"></flux:button>
                                    </flux:modal.trigger>
                                    <flux:button wire:click="toggleStatus({{ $data->id }})"
                                        wire:confirm="Are you sure you want to {{ $data->active_status == '1' ? 'deactivate' : 'activate' }} this Position?"
                                        size="sm" icon="{{ $data->active_status == '1' ? 'no-symbol' : 'check' }}"
                                        variant="{{ $data->active_status == '1' ? 'danger' : 'primary' }}">
                                    </flux:button>
                                </td>
                            </tr>
                        @empty
                            <tr colspan="4">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-slate-900 dark:text-slate-100">No Position Found!
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>



                <div class="mt-4 mx-10">
                    {{ $positionList->links() }}
                </div>
            </div>
        </div>

        <flux:modal wire:model="showModelNewPosition" name="add-new-position" class="md:w-96">
            <div class="space-y-6">
                <div>
                    <flux:heading size="lg">Add new Position</flux:heading>
                    <flux:text class="mt-2">Add new Position to your system.
                    </flux:text>
                </div>
                @if (session()->has('error'))
                    <div class="p-3 mb-5 rounded-md bg-red-100 text-red-800 text-sm font-semibold">
                        {{ session('error') }}
                    </div>
                @endif
                <form wire:submit.prevent="addNewPosition">
                    @csrf
                    <div class="mt-6 max-w-xl space-y-4">

                        <flux:field>
                            <flux:input label="Position ID" wire:model.live="positionId"
                                placeholder="Enter Position ID" mask="POS999"/>
                        </flux:field>

                        <flux:field>
                            <flux:select label="Service" id="service" wire:model.live="serviceId">
                                <option value="">{{ __ ('Select Service') }}</option>
                                @foreach ($serviceOption as $service)
                                    <option value="{{ $service->service_id }}">{{ $service->service_name }}</option>
                                @endforeach
                            </flux:select>
                        </flux:field>

                        <flux:field>
                            <flux:input label="Position Name" wire:model.live="positionName"
                                placeholder="Enter Position Name" />
                        </flux:field>

                        <flux:field>
                            <flux:textarea label="Description" wire:model.live="updatePositionDescription"
                                placeholder="Enter Description" />
                        </flux:field>

                    </div>

                    <div class="flex mt-4">
                        <flux:spacer />
                        <flux:button type="submit" variant="primary">Add New Position</flux:button>
                    </div>
                </form>
            </div>
        </flux:modal>

        <flux:modal wire:model="showModelEditPosition" name="edit-position" class="md:w-96">
            <div class="space-y-6">
                <div>
                    <flux:heading size="lg">Edit Position</flux:heading>
                    <flux:text class="mt-2">Change Position information on your system.
                    </flux:text>
                </div>
                @if (session()->has('error'))
                    <div class="p-3 mb-5 rounded-md bg-red-100 text-red-800 text-sm font-semibold">
                        {{ session('error') }}
                    </div>
                @endif
                <form wire:submit.prevent="updatePosition">
                    @csrf
                    <div class="mt-6 max-w-xl space-y-4">

                        <flux:field>
                            <flux:input disabled label="Position ID" wire:model.live="updatePositionId"
                                placeholder="Enter Position ID" mask="POS999"/>
                        </flux:field>

                        <flux:field>
                            <flux:select label="Service" id="service" wire:model.live="updateServiceId">
                                <option value="">{{ __ ('Select Service') }}</option>
                                @foreach ($serviceOption as $service)
                                    <option value="{{ $service->service_id }}">{{ $service->service_name }}</option>
                                @endforeach
                            </flux:select>
                        </flux:field>

                        <flux:field>
                            <flux:input label="Position Name" wire:model.live="updatePositionName"
                                placeholder="Enter Position Name" />
                        </flux:field>

                        <flux:field>
                            <flux:textarea label="Description" wire:model.live="updatePositionDescription"
                                placeholder="Enter Description" />
                        </flux:field>

                    </div>

                    <div class="flex mt-4">
                        <flux:spacer />
                        <flux:button type="submit" name="edit" variant="primary">Save changes</flux:button>
                    </div>
                </form>
            </div>
        </flux:modal>

    </x-main-tables.layout>
</section>
