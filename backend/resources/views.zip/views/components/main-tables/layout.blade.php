<div class="flex items-start max-md:flex-col">
    <div class="me-10 w-full pb-4 md:w-[220px] md:sticky md:top-4 md:max-h-[calc(85vh-2rem)] overflow-y-auto"
        x-data
        x-init="
            const key = 'side-nav-scroll';
            $el.scrollTop = sessionStorage.getItem(key) || 0;
            $el.addEventListener('scroll', () => sessionStorage.setItem(key, $el.scrollTop));">
            
        <flux:navlist>
            {{-- <flux:navlist.item :href="route('main-tables.overview')" :current="request()->routeIs('main-tables.overview')" wire:navigate>{{ __('Overview') }}</flux:navlist.item> --}}
            <flux:navlist.item :href="route('main-tables.authorities')" :current="request()->routeIs('main-tables.authorities')" wire:navigate>{{ __('Authorities') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.blood-group')" :current="request()->routeIs('main-tables.blood-group')" wire:navigate>{{ __('Blood Groups') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.city-list')" :current="request()->routeIs('main-tables.city-list')" wire:navigate>{{ __('City List') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.civil-status')" :current="request()->routeIs('main-tables.civil-status')" wire:navigate>{{ __('Civil Status') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.district')" :current="request()->routeIs('main-tables.district')" wire:navigate>{{ __('Districts') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.ds-office')" :current="request()->routeIs('main-tables.ds-office')" wire:navigate>{{ __('DS Offices') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.education-qualifications')" :current="request()->routeIs('main-tables.education-qualifications')" wire:navigate>{{ __('Education Qualifications') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.educational-qualification-grades')" :current="request()->routeIs('main-tables.educational-qualification-grades')" wire:navigate>{{ __('Edu. Qualification Grades') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.ethnicities')" :current="request()->routeIs('main-tables.ethnicities')" wire:navigate>{{ __('Ethnicities') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.genders')" :current="request()->routeIs('main-tables.genders')" wire:navigate>{{ __('Genders') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.gn-divisions')" :current="request()->routeIs('main-tables.gn-divisions')" wire:navigate>{{ __('GN Divisions') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.institution-grade-spans')" :current="request()->routeIs('main-tables.institution-grade-spans')" wire:navigate>{{ __('Ins. Grade Spans') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.institution-authorities')" :current="request()->routeIs('main-tables.institution-authorities')" wire:navigate>{{ __('Ins. Authorities') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.institution-categories')" :current="request()->routeIs('main-tables.institution-categories')" wire:navigate>{{ __('Ins. Categories') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.institution-ethnicities')" :current="request()->routeIs('main-tables.institution-ethnicities')" wire:navigate>{{ __('Ins. Ethnicities') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.institution-genders')" :current="request()->routeIs('main-tables.institution-genders')" wire:navigate>{{ __('Ins. Genders') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.institution-languages')" :current="request()->routeIs('main-tables.institution-languages')" wire:navigate>{{ __('Ins. Languages') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.institution-types')" :current="request()->routeIs('main-tables.institution-types')" wire:navigate>{{ __('Ins. Types') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.institutional-facilities')" :current="request()->routeIs('main-tables.institutional-facilities')" wire:navigate>{{ __('Ins. Facilities') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.medium-of-instructions')" :current="request()->routeIs('main-tables.medium-of-instructions')" wire:navigate>{{ __('Instructions Medium') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.occupations-lists')" :current="request()->routeIs('main-tables.occupations-lists')" wire:navigate>{{ __('Occupations List') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.office-levels')" :current="request()->routeIs('main-tables.office-levels')" wire:navigate>{{ __('Office Levels') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.police-stations')" :current="request()->routeIs('main-tables.police-stations')" wire:navigate>{{ __('Police Stations') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.positions')" :current="request()->routeIs('main-tables.positions')" wire:navigate>{{ __('Positions') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.principal-recruitment-categories')" :current="request()->routeIs('main-tables.principal-recruitment-categories')" wire:navigate>{{ __('Principal Rec. Categories') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.provinces-lists')" :current="request()->routeIs('main-tables.provinces-lists')" wire:navigate>{{ __('Provinces List') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.religions')" :current="request()->routeIs('main-tables.religions')" wire:navigate>{{ __('Religions') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.sleas-categories')" :current="request()->routeIs('main-tables.sleas-categories')" wire:navigate>{{ __('SLEAS Categories') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.sleas-subjects')" :current="request()->routeIs('main-tables.sleas-subjects')" wire:navigate>{{ __('SLEAS Subjects') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.services')" :current="request()->routeIs('main-tables.services')" wire:navigate>{{ __('Services') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.service-ranks')" :current="request()->routeIs('main-tables.service-ranks')" wire:navigate>{{ __('Service Ranks') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.teacher-categories')" :current="request()->routeIs('main-tables.teacher-categories')" wire:navigate>{{ __('Teacher Categories') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.teacher-types')" :current="request()->routeIs('main-tables.teacher-types')" wire:navigate>{{ __('Teacher Types') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.titles')" :current="request()->routeIs('main-tables.titles')" wire:navigate>{{ __('Titles') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.appointed-subjects')" :current="request()->routeIs('main-tables.appointed-subjects')" wire:navigate>{{ __('Appointed Subjects') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.teaching-subjects')" :current="request()->routeIs('main-tables.teaching-subjects')" wire:navigate>{{ __('Teaching Subjects') }}</flux:navlist.item>

            <flux:navlist.item :href="route('main-tables.versions')" :current="request()->routeIs('main-tables.versions')" wire:navigate>{{ __('Versions') }}</flux:navlist.item>
            <flux:navlist.item :href="route('main-tables.change-logs')" :current="request()->routeIs('main-tables.change-logs')" wire:navigate>{{ __('Change Logs') }}</flux:navlist.item>
        </flux:navlist>
    </div>

    <flux:separator class="md:hidden" />

    <div class="flex-1 self-stretch max-md:pt-6">
        <div class="mt-5 w-full max-w-6xl">
            {{ $slot }}
        </div>
    </div>
</div>
