<div class="flex items-start max-md:flex-col">
    <div class="me-10 w-full pb-4 md:w-[220px]">
        <flux:navlist>
            <flux:navlist.item :href="route('mso.profile.index', $msoid)"
                :current="request()->routeIs('mso.profile.index')" wire:navigate>{{ __('General') }}
            </flux:navlist.item>

            @can('mso.profile.qualification.view')
            <flux:navlist.item :href="route('mso.profile.qualification', $msoid)"
                :current="request()->routeIs('mso.profile.qualification')" wire:navigate>{{ __('Qualification') }}
            </flux:navlist.item>
            @endcan

            @can('mso.profile.employment.view')
            <flux:navlist.item :href="route('mso.profile.employment', $msoid)"
                :current="request()->routeIs('mso.profile.employment')" wire:navigate>{{ __('Employment') }}
            </flux:navlist.item>
            @endcan

            <flux:navlist.item :href="route('mso.profile.pension-and-payment', $msoid)"
                :current="request()->routeIs('mso.profile.pension-and-payment')" wire:navigate>{{ __('W&OP and Payment') }}
            </flux:navlist.item>

            @can('mso.profile.family.view')
            <flux:navlist.item :href="route('mso.profile.family', $msoid)"
                :current="request()->routeIs('mso.profile.family')" wire:navigate>{{ __('Family') }}
            </flux:navlist.item>
            @endcan

            @can('mso.profile.edit-request.view')
            <flux:navlist.item :href="route('mso.profile.edit-request', $msoid)"
                :current="request()->routeIs('mso.profile.edit-request')" wire:navigate>{{ __('Edit Request') }}
            </flux:navlist.item>
            @endcan

        </flux:navlist>
    </div>

    <flux:separator class="md:hidden" />

    <div class="flex-1 self-stretch max-md:pt-4">
        <div class="mt-5 w-full max-w-5xl">
            {{-- Profile Header --}}
            <div class="w-full mb-8">
                <div
                    class="relative group bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-sm hover:shadow-md overflow-hidden">

                    <div
                        class="absolute inset-0 bg-gradient-to-br from-blue-50/50 via-transparent to-purple-50/50 dark:from-blue-900/10 dark:to-purple-900/10 pointer-events-none">
                    </div>
                    <div
                        class="absolute top-0 right-0 -mt-16 -mr-16 w-48 h-48 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-full blur-3xl">
                    </div>

                    <div class="relative p-6">
                        <div class="flex flex-col md:flex-row gap-6 items-start">

                            <div class="flex-shrink-0 flex flex-col items-center md:items-start mx-auto md:mx-0">
                                <div class="relative">
                                    <div
                                        class="absolute -inset-1 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl opacity-20 blur-sm">
                                    </div>
                                    @if ($mso->gender_id == 'G02')
                                    <img src="{{ asset('images/profile_f.png') }}" alt="Profile"
                                        class="relative w-24 h-24 rounded-2xl object-cover border-2 border-white dark:border-gray-800 shadow-md ring-1 ring-gray-900/5 dark:ring-white/10" />
                                    @else
                                    <img src="{{ asset('images/profile_m.png') }}" alt="Profile"
                                        class="relative w-24 h-24 rounded-2xl object-cover border-2 border-white dark:border-gray-800 shadow-md ring-1 ring-gray-900/5 dark:ring-white/10" />
                                    @endif

                                    <span class="absolute -bottom-1 -right-1 md:hidden flex h-4 w-4">
                                        <span
                                            class="animate-ping absolute inline-flex h-full w-full rounded-full {{ $mso->appointment->is_confirmed ? 'bg-green-400' : 'bg-red-400' }} opacity-75"></span>
                                        <span
                                            class="relative inline-flex rounded-full h-4 w-4 border-2 border-white dark:border-gray-900 {{ $mso->appointment->is_confirmed ? 'bg-green-500' : 'bg-red-500' }}"></span>
                                    </span>
                                </div>
                                <div class=" flex w-full items-center justify-center">
                                    <p class="mt-2 text-xs font-medium text-gray-500 dark:text-gray-400 text-center md:text-left">
                                        {{ $mso->appointment->service->service_name }}
                                    </p>
                                </div>
                            </div>

                            <div class="flex-1 min-w-0 w-full text-center md:text-left">

                                <div
                                    class="flex flex-col md:flex-row md:items-center gap-2 mb-4 justify-center md:justify-start">
                                    <h1 class="text-2xl font-bold text-gray-900 dark:text-white truncate">
                                        {{ $mso->title->title_name }} {{ $mso->name_with_initials }}
                                    </h1>

                                    @if ($mso->appointment->is_confirmed)
                                    <span
                                        class="inline-flex items-center self-center md:self-auto px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300 border border-green-200 dark:border-green-800">
                                        <span class="w-1.5 h-1.5 bg-green-500 rounded-full mr-1.5"></span>
                                        Confirmed
                                    </span>
                                    @elseif($mso->appointment->is_verified)
                                    <span
                                        class="inline-flex items-center self-center md:self-auto px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300 border border-orange-200 dark:border-orange-800">
                                        <span class="w-1.5 h-1.5 bg-orange-500 rounded-full mr-1.5"></span>
                                        Verified
                                    </span>
                                    @else
                                    <span
                                        class="inline-flex items-center self-center md:self-auto px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300 border border-red-200 dark:border-red-800">
                                        <span class="w-1.5 h-1.5 bg-red-500 rounded-full mr-1.5"></span>
                                        Not Confirmed
                                    </span>
                                    @endif
                                </div>

                                <div class="grid grid-cols-1 xs:grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
                                    @php
                                    $fields = [
                                    ['label' => 'National ID', 'value' => $mso->nic],
                                    ['label' => 'Employee ID', 'value' => $mso->people_id],
                                    ['label' => 'W&OP No', 'value' => $mso->appointment->w_op_no ?? 'N/A'],
                                    [
                                    'label' => 'Pay Sheet No',
                                    'value' => $mso->appointment->pay_sheet_no ?? 'N/A',
                                    ],
                                    ];
                                    @endphp

                                    @foreach ($fields as $field)
                                    <div
                                        class="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-2.5 border border-gray-100 dark:border-gray-700">
                                        <p
                                            class="text-[10px] uppercase tracking-wider font-semibold text-gray-500 dark:text-gray-400 mb-0.5">
                                            {{ $field['label'] }}
                                        </p>
                                        <p class="font-mono text-sm font-medium text-gray-900 dark:text-gray-200 truncate"
                                            title="{{ $field['value'] }}">
                                            {{ $field['value'] }}
                                        </p>
                                    </div>
                                    @endforeach
                                </div>

                                <div class="flex flex-col sm:flex-row gap-3">

                                    @can('mso.profile.edit-request.create')
                                    <flux:modal.trigger name="edit-profile">
                                        <button
                                            class="flex-1 sm:flex-none inline-flex justify-center items-center px-4 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 shadow-sm">
                                            <svg class="w-4 h-4 mr-2 text-gray-500" fill="none" stroke="currentColor"
                                                viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z">
                                                </path>
                                            </svg>
                                            Send Edit Request
                                        </button>
                                    </flux:modal.trigger>
                                    @endcan

                                    @can('mso.profile.pdf.view')
                                    <a href="{{ route('teacher.profile.pdf', $mso->id) }}" target="_blank"
                                        class="flex-1 sm:flex-none">
                                        <button
                                            class="w-full sm:w-auto inline-flex justify-center items-center px-4 py-2 bg-blue-600 border border-transparent rounded-lg text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors shadow-sm">
                                            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor"
                                                viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.5l5 5v2m0 0h-5">
                                                </path>
                                            </svg>
                                            Get Document
                                        </button>
                                    </a>
                                    @endcan
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <!-- Add condition to check if profile is confirmed -->
            @if (!$mso->appointment?->is_confirmed && !$mso->appointment?->is_verified)
            @can('mso.profile.verify')
            <div class="mb-6">
                <x-alert type="warning" :dismissible="false">
                    <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                        <div class="flex flex-col gap-1">
                            <span class="font-semibold">Profile Not Verified</span>
                            <span>This profile has not been verified yet. Please review the details.</span>
                        </div>
                        <flux:modal.trigger name="verify-profile">
                            <button
                                class="px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors text-sm font-medium whitespace-nowrap shadow-sm">
                                Verify
                            </button>
                        </flux:modal.trigger>
                    </div>
                </x-alert>
            </div>
            @endcan
            @elseif(!$mso->appointment?->is_confirmed && $mso->appointment?->is_verified)
            @can('mso.profile.confirm')
            <div class="mb-6">
                <x-alert type="warning" :dismissible="false">
                    <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                        <div class="flex flex-col gap-1">
                            <span class="font-semibold">Profile Not Confirmed</span>
                            <span>This profile has not been confirmed yet. Please review the details.</span>
                        </div>
                        <flux:modal.trigger name="confirm-profile">
                            <button
                                class="px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors text-sm font-medium whitespace-nowrap shadow-sm">
                                Confirm
                            </button>
                        </flux:modal.trigger>
                    </div>
                </x-alert>
            </div>
            @endcan
            @endif

            @if ($mso->profileEditRequests->where('status', 1)->isNotEmpty())
            @can('mso.profile.edit-request.response')
            <div class="mb-6">
                <x-alert type="info" :dismissible="false">
                    <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                        <div class="flex flex-col gap-1">
                            <span class="font-semibold">Profile Edit Request Pending</span>
                            <span>You have a pending profile edit request. Please wait for approval.</span>
                        </div>
                        <flux:modal.trigger name="edit-profile-request-response">
                            <button
                                class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium whitespace-nowrap shadow-sm">
                                Response
                            </button>
                        </flux:modal.trigger>
                    </div>
                </x-alert>
            </div>
            @endcan
            @endif

            <div>
                @if (session('success'))
                <x-alert type="success" dismissible class="mb-4">
                    {{ session('success') }}
                </x-alert>
                @endif

                @if (session('error'))
                <x-alert type="error" dismissible class="mb-4">
                    {{ session('error') }}
                </x-alert>
                @endif

                @if (session('warning'))
                <x-alert type="warning" dismissible class="mb-4">
                    {{ session('warning') }}
                </x-alert>
                @endif

                @if (session('info'))
                <x-alert type="info" dismissible class="mb-4">
                    {{ session('info') }}
                </x-alert>
                @endif
            </div>

            {{ $slot }}
        </div>
    </div>

    @can('mso.profile.edit-request.create')
    <!-- Edit Profile Modal -->
    <flux:modal name="edit-profile" class="md:w-150">
        <livewire:m-s-o.complaint-form :peopleId="$mso->people_id" />
    </flux:modal>
    @endcan

    @can('mso.profile.confirm')
    <!-- Confirm Profile Modal -->
    <flux:modal name="confirm-profile" class="md:w-96">
        <div class="space-y-6">
            <livewire:employees.confirm-profile-form :peopleId="$mso->people_id" />
        </div>
    </flux:modal>
    @endcan

    @can('mso.profile.verify')
    <!-- Verify Profile Modal -->
    <flux:modal name="verify-profile" class="md:w-96">
        <div class="space-y-6">
            <livewire:employees.verify-profile-form :peopleId="$mso->people_id" />
        </div>
    </flux:modal>
    @endcan

    @can('mso.profile.edit-request.response')
    <flux:modal name="edit-profile-request-response" class="md:w-150">
        <livewire:employees.edit-profile-requst-response-form :peopleId="$mso->people_id" />
    </flux:modal>
    @endcan
</div>