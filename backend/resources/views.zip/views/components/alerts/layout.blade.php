<div class="flex items-start max-md:flex-col">
    <div class="me-10 w-full pb-4 md:w-[220px] md:sticky md:top-4 md:max-h-[calc(85vh-2rem)] overflow-y-auto"
        x-data
        x-init="
            const key = 'side-nav-scroll';
            $el.scrollTop = sessionStorage.getItem(key) || 0;
            $el.addEventListener('scroll', () => sessionStorage.setItem(key, $el.scrollTop));">
            
        <flux:navlist>
            <flux:navlist.item icon="home" 
                :href="route('alerts.overview')" 
                :current="request()->routeIs('alerts.overview')" 
                wire:navigate>
                {{ __('Overview') }}
            </flux:navlist.item>
            @canany([
                'teacher.profile.confirm',
                'principal.profile.confirm',
                'dos.profile.confirm',
                'mso.profile.confirm',
                'sleas.profile.confirm',
                'sltas.profile.confirm',
                'sltes.profile.confirm'
            ])
                <flux:navlist.item icon="check-circle"
                    :href="route('alerts.pending-confirmation')"
                    :current="request()->routeIs('alerts.pending-confirmation')"
                    wire:navigate>
                    {{ __('Pending Confirmation') }}
                </flux:navlist.item>
            @endcanany

            @canany([
                'teacher.profile.verify',
                'principal.profile.verify',
                'dos.profile.verify',
                'mso.profile.verify',
                'sleas.profile.verify',
                'sltas.profile.verify',
                'sltes.profile.verify'
            ])
                <flux:navlist.item icon="shield-check"
                    :href="route('alerts.pending-verification')"
                    :current="request()->routeIs('alerts.pending-verification')"
                    wire:navigate>
                    {{ __('Pending Verification') }}
                </flux:navlist.item>
            @endcanany
        </flux:navlist>
    </div>

    <flux:separator class="md:hidden" />

    <div class="flex-1 self-stretch max-md:pt-6">
        <div class="mt-5 w-full max-w-6xl">
            {{ $slot }}
        </div>
    </div>
</div>
