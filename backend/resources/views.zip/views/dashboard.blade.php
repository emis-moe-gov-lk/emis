<x-layouts.app :title="__('Dashboard')">
    <!-- Header Section -->
    <div class="mb-8">
        <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between">
            <div>
                <h1 class="text-3xl font-bold text-gray-800">Education Management Dashboard</h1>
                <p class="text-gray-600 mt-2">Welcome to the National Education Management System</p>

            </div>
            <div class="flex items-center space-x-4 mt-4 lg:mt-0">
                <div class="text-right hidden lg:block">
                    <p class="text-sm font-medium text-gray-800">{{ now()->format('l, F j, Y') }}</p>
                    <p class="text-sm text-gray-500">{{ $user->workplace->full_workplace->name ?? 'National System' }}
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Welcome Card & Quick Stats -->
    <div class="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
        <!-- Welcome Card -->
        <div
            class="lg:col-span-2 relative overflow-hidden rounded-2xl bg-gradient-to-br from-blue-50 to-indigo-100 border border-blue-100 p-6 shadow-sm hover:shadow-md transition-all duration-300 group">
            <div class="relative z-10">
                <div class="flex items-start justify-between">
                    <div class="flex-1">
                        <h2 class="text-2xl font-bold text-gray-800 mb-2">Welcome back, {{ $user->name }}! 👋</h2>
                        <p class="text-gray-600 mb-4">Here's what's happening in the education system today.</p>

                        @if ($user->workplace)
                        <div class="space-y-2">
                            <div
                                class="flex items-center text-gray-700 bg-white/60 rounded-lg p-3 backdrop-blur-sm border border-white/80">
                                <svg class="w-5 h-5 mr-3 text-blue-500" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4">
                                    </path>
                                </svg>
                                <span
                                    class="font-medium text-gray-800">{{ $user->full_workplace->name ?? 'Not Assigned' }}</span>
                            </div>

                            <a href="{{route('my-profile.index')}}">
                                <div
                                    class="flex items-center text-gray-700 bg-white/60 rounded-lg p-3 backdrop-blur-sm border border-white/80">
                                    <svg class="w-5 h-5 mr-3 text-indigo-500" fill="none" stroke="currentColor"
                                        viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M10 6H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V8a2 2 0 00-2-2h-5m-4 0V5a2 2 0 114 0v1m-4 0a2 2 0 104 0m-5 8a2 2 0 100-4 2 2 0 000 4zm0 0c1.306 0 2.417.835 2.83 2M9 14a3.001 3.001 0 00-2.83 2M15 11h3m-3 4h2">
                                        </path>
                                    </svg>
                                    <span class="text-gray-800">My Profile</span>
                                </div>
                            </a>
                        </div>
                        @else
                        <p
                            class="text-gray-500 italic bg-white/60 rounded-lg p-3 backdrop-blur-sm border border-white/80">
                            No active workplace assigned.</p>
                        @endif
                    </div>
                    <div
                        class="ml-6 p-3 bg-white/80 rounded-xl border border-white/80 backdrop-blur-sm group-hover:scale-105 transition-transform">
                        <svg class="w-8 h-8 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                        </svg>
                    </div>
                </div>
            </div>
            <!-- Background decoration -->
            <div
                class="absolute top-0 right-0 w-32 h-32 bg-white/30 rounded-full -translate-y-16 translate-x-16 backdrop-blur-sm">
            </div>
            <div
                class="absolute bottom-0 left-0 w-24 h-24 bg-white/20 rounded-full translate-y-12 -translate-x-12 backdrop-blur-sm">
            </div>
        </div>

        <!-- Quick Stats -->
        <div
            class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md hover:border-blue-100 transition-all duration-300 group cursor-pointer">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-800">Institutions</h3>
                <div class="p-3 bg-blue-50 rounded-xl group-hover:scale-110 transition-transform">
                    <svg class="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4">
                        </path>
                    </svg>
                </div>
            </div>
            <div class="text-3xl font-bold text-gray-800 mb-2">{{ $institutionCount }}</div>
            <div class="flex items-center text-green-600 font-medium">
                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>
                </svg>
                <span class="text-sm">100% Government schools</span>
            </div>
        </div>

        <div
            class="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md hover:border-green-100 transition-all duration-300 group cursor-pointer">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-800">Teachers</h3>
                <div class="p-3 bg-green-50 rounded-xl group-hover:scale-110 transition-transform">
                    <svg class="w-6 h-6 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z">
                        </path>
                    </svg>
                </div>
            </div>
            <div class="text-3xl font-bold text-gray-800 mb-2">{{$teachersCount}}</div>
            <div class="flex items-center text-green-600 font-medium">
                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"></path>
                </svg>
                <span class="text-sm">+0% enrollment</span>
            </div>
        </div>
    </div>

    <!-- Regional Distribution -->
    <div class="bg-white rounded-2xl p-8 shadow-xl border border-gray-100 mb-10">
        <div class="flex items-center justify-between mb-8">
            <h3 class="text-2xl font-bold text-gray-900">🗺️ Regional Distribution</h3>
            <button class="text-green-600 hover:text-green-700 font-semibold text-sm tracking-wide flex items-center space-x-1 group transition-colors duration-200">
                <span>View detailed report</span>
                <svg class="w-4 h-4 transform group-hover:translate-x-1 transition-transform" fill="none"
                    stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                </svg>
            </button>
        </div>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
            @foreach ($provinceCounts as $region)
            <div
                class="bg-teal-50 p-6 rounded-2xl border border-teal-200 text-center transition-all duration-300 transform hover:scale-105 hover:shadow-lg cursor-pointer
                hover:bg-teal-100 group">
                <div class="text-xl font-extrabold text-teal-700 mb-1 leading-snug group-hover:text-teal-800">{{ $region->province_name }}</div>
                <div class="text-lg font-medium text-gray-700 mt-2">{{ $region->total_institutions }} Institutions</div>
            </div>
            @endforeach
        </div>
    </div>

    <div class="bg-white rounded-2xl p-8 shadow-xl border border-gray-100 mb-10">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between mb-8 gap-4">
            <h3 class="text-2xl font-bold text-gray-900">🗺️ Regional Distribution</h3>
            <div class="flex items-center space-x-4">
                <div class="relative">
                    <svg class="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                    </svg>
                    <input type="text" placeholder="Search province..." class="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-teal-500 w-64">
                </div>
                <button class="text-green-600 hover:text-green-700 font-semibold text-sm tracking-wide flex items-center space-x-1 group transition-colors duration-200">
                    <span>View All</span>
                    <svg class="w-4 h-4 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                    </svg>
                </button>
            </div>
        </div>

        <!-- Card List -->
        <div class="space-y-6">
            <!-- Province 1 -->
            @foreach ($provinceCounts as $region)
            <div class="group bg-gradient-to-r from-white to-gray-50 hover:to-teal-50 border border-gray-200 rounded-2xl p-6 hover:shadow-xl transition-all duration-300 hover:border-teal-300 cursor-pointer">
                <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                    <!-- Left Section: Basic Info -->
                    <div class="flex items-start space-x-4 flex-1">
                        <div class="w-16 h-16 bg-teal-100 rounded-2xl flex items-center justify-center group-hover:bg-teal-200 transition-colors">
                            <span class="text-3xl">🏛️</span>
                        </div>
                        <div class="flex-1">
                            <div class="flex items-center space-x-3 mb-2">
                                <h4 class="text-xl font-bold text-gray-900">{{ $region->province_name }}</h4>
                                <span class="px-3 py-1 bg-teal-100 text-teal-800 rounded-full text-xs font-semibold">
                                    Highest Performance
                                </span>
                            </div>
                            <p class="text-gray-600 mb-3">Capital Region • {{ $region->total_institutions }} Educational Institutions</p>
                            <div class="flex flex-wrap gap-4">
                                <div class="flex items-center text-gray-700">
                                    <span class="text-purple-500 mr-2">👨‍🏫</span>
                                    <span class="font-medium">{{ $region->total_institutions }} Teachers</span>
                                </div>
                                <div class="flex items-center text-gray-700">
                                    <span class="text-blue-500 mr-2">💼</span>
                                    <span class="font-medium">{{ $region->total_institutions }} Admin</span>
                                </div>
                                <div class="flex items-center text-gray-700">
                                    <span class="text-orange-500 mr-2">🛠️</span>
                                    <span class="font-medium">{{ $region->total_institutions }} Support</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Right Section: Stats -->
                    <div class="lg:w-2/5 space-y-4">
                        <div class="grid grid-cols-2 gap-4">
                            <div class="bg-white p-4 rounded-xl border border-gray-100">
                                <div class="text-sm text-gray-600 mb-1">Total Staff</div>
                                <div class="text-2xl font-bold text-gray-900">2,850</div>
                            </div>
                            <div class="bg-white p-4 rounded-xl border border-gray-100">
                                <div class="text-sm text-gray-600 mb-1">Student Ratio</div>
                                <div class="text-2xl font-bold text-gray-900">1:28</div>
                            </div>
                        </div>

                        <!-- Performance Bar -->
                        <div>
                            <div class="flex justify-between text-sm mb-2">
                                <span class="font-medium text-gray-700">Performance Score</span>
                                <span class="font-bold text-green-600">82.5%</span>
                            </div>
                            <div class="w-full bg-gray-200 rounded-full h-3">
                                <div class="bg-gradient-to-r from-green-400 to-green-500 h-3 rounded-full" style="width: 82.5%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>

        <!-- Load More Button -->
        <div class="mt-8 text-center">
            <button class="px-6 py-3 bg-gradient-to-r from-teal-500 to-green-500 text-white font-semibold rounded-xl hover:shadow-lg transition-all duration-300 hover:scale-105">
                Load More Provinces
                <svg class="w-5 h-5 inline-block ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"></path>
                </svg>
            </button>
        </div>
    </div>
</x-layouts.app>